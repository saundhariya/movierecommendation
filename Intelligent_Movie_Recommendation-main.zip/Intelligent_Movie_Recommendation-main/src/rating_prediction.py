"""
Intelligent Movie Recommendation System
Module 6: Rating Prediction Engine
----------------------------------
Predicts exact user ratings on a 0.5 - 5.0 scale using de-biased SVD matrix
factorization, user/item baseline biases, and content-sentiment affinity.
Provides transparent mathematical component breakdowns and explanations.
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, Optional

from collaborative_filter import CollaborativeFilteringSVD
from content_recommender import ContentBasedRecommender


class RatingPredictionService:
    """
    Dedicated service for predicting user ratings with full mathematical
    attribution (Global Mean + User Bias + Item Bias + Latent Interaction).
    """

    def __init__(self, models_dir: str = None):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        self.cf_model = CollaborativeFilteringSVD(models_dir=self.models_dir)
        self.cb_model = ContentBasedRecommender(models_dir=self.models_dir)

        self.movies_df = None
        self.ratings_df = None
        self.sentiment_map = {}
        self.global_mean = 3.50
        self.user_biases = {}
        self.item_biases = {}
        self.is_ready = False

    def initialize(
        self,
        movies_df: pd.DataFrame,
        ratings_df: pd.DataFrame,
        sentiment_map: Dict[int, Any] = None
    ):
        """Initializes baseline biases and loads model dependencies."""
        self.movies_df = movies_df.copy()
        self.ratings_df = ratings_df.copy()
        self.sentiment_map = sentiment_map or {}

        # Load SVD and Content models
        if not self.cf_model.is_fitted:
            self.cf_model.load_model()
        if not self.cb_model.is_fitted:
            self.cb_model.load_model()

        self.global_mean = float(self.ratings_df["rating"].mean())

        # Precompute user biases: b_u = mean(r_u) - mu
        user_means = self.ratings_df.groupby("userId")["rating"].mean()
        self.user_biases = (user_means - self.global_mean).to_dict()

        # Precompute item biases: b_i = mean(r_i) - mu
        item_means = self.ratings_df.groupby("movieId")["rating"].mean()
        self.item_biases = (item_means - self.global_mean).to_dict()

        self.is_ready = True
        print("RatingPredictionService initialized with bias models.")

    def predict_detailed(self, user_id: int, movie_id: int) -> Dict[str, Any]:
        """
        Computes predicted rating with mathematical breakdown and explanation.
        """
        if not self.is_ready:
            raise RuntimeError("RatingPredictionService has not been initialized.")

        # Movie metadata lookup
        m_rows = self.movies_df[self.movies_df["movieId"] == movie_id]
        if m_rows.empty:
            movie_title = f"Movie #{movie_id}"
            genres = "Unknown"
            year = None
            avg_rating = self.global_mean
            rating_count = 0
        else:
            row = m_rows.iloc[0]
            movie_title = str(row.get("title", f"Movie #{movie_id}"))
            genres = str(row.get("genres", "Unknown"))
            year = row.get("year", None)
            avg_rating = float(row.get("rating_mean", self.global_mean))
            rating_count = int(row.get("rating_count", 0))

        # Check user history
        user_ratings = self.ratings_df[self.ratings_df["userId"] == user_id]
        user_seen = not user_ratings.empty
        actual_rating = None
        if user_seen:
            existing = user_ratings[user_ratings["movieId"] == movie_id]
            if not existing.empty:
                actual_rating = float(existing["rating"].values[0])

        # Mathematical components
        mu = self.global_mean
        b_u = float(self.user_biases.get(user_id, 0.0))
        b_i = float(self.item_biases.get(movie_id, avg_rating - mu))

        # Latent interaction from SVD
        latent_interaction = 0.0
        if self.cf_model.is_fitted and user_id in self.cf_model.user_id_to_idx and movie_id in self.cf_model.movie_id_to_idx:
            u_idx = self.cf_model.user_id_to_idx[user_id]
            m_idx = self.cf_model.movie_id_to_idx[movie_id]
            u_vec = self.cf_model.user_latent[u_idx]
            m_vec = self.cf_model.item_latent[m_idx]
            latent_interaction = float(np.dot(u_vec, m_vec))

        raw_pred = mu + b_u + b_i + latent_interaction
        clamped_pred = float(np.clip(raw_pred, 0.5, 5.0))

        # Recommendation confidence score (0 to 100%)
        # Based on rating strength and review sentiment
        rec_score = min(100.0, max(10.0, (clamped_pred / 5.0) * 100.0))

        # Review sentiment signal
        sent_info = self.sentiment_map.get(movie_id, None)
        sent_text = ""
        if sent_info:
            pos_pct = int(sent_info.get("pos_ratio", 0) * 100)
            sent_text = f" Audience consensus is {pos_pct}% positive."

        # Structured explanation
        if b_u > 0.2:
            user_tendency = "You generally rate movies favorably"
        elif b_u < -0.2:
            user_tendency = "You are a critical reviewer with higher standards"
        else:
            user_tendency = "Your rating history matches average benchmarks"

        if b_i > 0.2:
            item_tendency = f"'{movie_title}' is broadly acclaimed by audiences"
        elif b_i < -0.2:
            item_tendency = f"'{movie_title}' has received mixed or polarizing reviews"
        else:
            item_tendency = f"'{movie_title}' maintains steady consensus ratings"

        explanation = (
            f"Predicted {clamped_pred:.2f}★ based on baseline trends ({mu:.2f}★ global average). "
            f"{user_tendency} (bias: {b_u:+.2f}), while {item_tendency} (bias: {b_i:+.2f}). "
            f"Collaborative latent preference contributed {latent_interaction:+.2f}★.{sent_text}"
        )

        return {
            "movieId": movie_id,
            "movie_title": movie_title,
            "genres": genres,
            "year": year,
            "actual_rating": actual_rating,
            "predicted_rating": round(clamped_pred, 2),
            "recommendation_score": round(rec_score, 1),
            "explanation": explanation,
            "components": {
                "global_mean": round(mu, 3),
                "user_bias": round(b_u, 3),
                "item_bias": round(b_i, 3),
                "latent_interaction": round(latent_interaction, 3),
                "unconstrained_prediction": round(raw_pred, 3),
            },
            "sentiment_summary": sent_info,
        }

    def save_model(self, filename: str = "rating_predictor.joblib") -> str:
        """Persists bias caches and rating predictor configuration."""
        save_path = os.path.join(self.models_dir, filename)
        payload = {
            "global_mean": self.global_mean,
            "user_biases": self.user_biases,
            "item_biases": self.item_biases,
            "sentiment_map": self.sentiment_map,
            "is_ready": self.is_ready,
        }
        joblib.dump(payload, save_path)
        print(f"Rating predictor saved to {save_path}")
        return save_path

    def load_model(self, filename: str = "rating_predictor.joblib") -> bool:
        """Loads persisted rating predictor cache."""
        load_path = os.path.join(self.models_dir, filename)
        if not os.path.exists(load_path):
            return False
        payload = joblib.load(load_path)
        self.global_mean = payload["global_mean"]
        self.user_biases = payload["user_biases"]
        self.item_biases = payload["item_biases"]
        self.sentiment_map = payload["sentiment_map"]
        self.is_ready = payload["is_ready"]
        print(f"Rating predictor loaded from {load_path}")
        return True


if __name__ == "__main__":
    print("Testing RatingPredictionService module...")
    from preprocessing import DataPreprocessor
    from hybrid_recommender import HybridRecommenderEngine

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    engine = HybridRecommenderEngine()
    engine.fit(
        movies_df=data["movies"],
        ratings_df=data["ratings"],
        reviews_df=data["reviews"],
        train_ratings_df=data["train_ratings"]
    )

    predictor = RatingPredictionService()
    predictor.initialize(
        movies_df=data["movies"],
        ratings_df=data["ratings"],
        sentiment_map=engine.sentiment_map
    )

    # Test predictions for User 1 on various movies
    test_movies = [1, 50, 318, 356]  # Toy Story, Usual Suspects, Shawshank, Forrest Gump
    print("\nDetailed rating predictions for User 1:")
    for mid in test_movies:
        res = predictor.predict_detailed(user_id=1, movie_id=mid)
        print(f"\nMovie: {res['movie_title']}")
        print(f"Predicted Rating: {res['predicted_rating']}★ (Actual: {res['actual_rating']}★)")
        print(f"Score: {res['recommendation_score']}%")
        print(f"Components: {res['components']}")
        print(f"Explanation: {res['explanation']}")

    predictor.save_model()
