"""
Intelligent Movie Recommendation System
Module 2: NLP and Sentiment Analysis Engine
-------------------------------------------
Implements review text normalization, tokenization, lemmatization,
TF-IDF feature extraction, VADER sentiment scoring, review classification,
and movie-level aggregate sentiment profiling.
"""

import os
import re
import string
import joblib
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from sklearn.feature_extraction.text import TfidfVectorizer


class SentimentAnalysisEngine:
    """
    NLP & Sentiment Analysis pipeline combining VADER lexical scoring
    with NLTK text processing and TF-IDF representation.
    """

    def __init__(self, models_dir: str = None):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        # Download / verify NLTK components
        self._ensure_nltk_resources()

        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words("english"))
        # Retain sentiment-influencing negation tokens
        self.negation_words = {"not", "no", "nor", "never", "hardly", "barely", "scarcely"}
        self.effective_stopwords = self.stop_words - self.negation_words

        self.sia = SentimentIntensityAnalyzer()
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 2),
            stop_words="english",
            min_df=2
        )
        self.is_fitted = False

    def _ensure_nltk_resources(self):
        """Ensures required corpora are loaded without unnecessary downloads."""
        appdata_nltk = os.path.join(os.environ.get("APPDATA", ""), "nltk_data")
        if os.path.exists(appdata_nltk) and appdata_nltk not in nltk.data.path:
            nltk.data.path.append(appdata_nltk)

        for package in ["sentiment/vader_lexicon.zip", "corpora/stopwords.zip", "tokenizers/punkt.zip", "corpora/wordnet.zip"]:
            try:
                nltk.data.find(package)
            except Exception:
                try:
                    pkg_name = package.split("/")[1].replace(".zip", "")
                    nltk.download(pkg_name, quiet=True)
                except Exception:
                    pass

    def preprocess_text(self, text: str) -> str:
        """
        Cleans and normalizes text:
        - Lowecase conversion
        - HTML tag and URL stripping
        - Punctuation removal
        - Tokenization & Lemmatization
        - Stopwords elimination
        """
        if not isinstance(text, str) or not text.strip():
            return ""

        # Lowercase
        text = text.lower()

        # Remove HTML and URLs
        text = re.sub(r"<.*?>", " ", text)
        text = re.sub(r"https?://\S+|www\.\S+", " ", text)

        # Remove punctuation and digits
        text = re.sub(f"[{re.escape(string.punctuation)}0-9]", " ", text)

        # Tokenize (fallback to regex if punkt is missing)
        try:
            tokens = word_tokenize(text)
        except Exception:
            tokens = re.findall(r"\b[a-z]{2,}\b", text)

        # Lemmatize and filter stopwords
        cleaned_tokens = [
            self.lemmatizer.lemmatize(token)
            for token in tokens
            if len(token) > 1 and token not in self.effective_stopwords
        ]

        return " ".join(cleaned_tokens)

    def score_sentiment(self, raw_text: str) -> Dict[str, Any]:
        """
        Computes VADER sentiment scores on raw text.
        VADER benefits from punctuation and capitalization in original text.
        """
        if not isinstance(raw_text, str) or not raw_text.strip():
            return {"neg": 0.0, "neu": 1.0, "pos": 0.0, "compound": 0.0, "label": "Neutral"}

        scores = self.sia.polarity_scores(raw_text)
        compound = scores["compound"]

        if compound >= 0.05:
            label = "Positive"
        elif compound <= -0.05:
            label = "Negative"
        else:
            label = "Neutral"

        return {
            "neg": scores["neg"],
            "neu": scores["neu"],
            "pos": scores["pos"],
            "compound": compound,
            "label": label,
        }

    def process_reviews_dataframe(self, reviews_df: pd.DataFrame) -> pd.DataFrame:
        """
        Annotates review dataframe with cleaned tokens, VADER sentiment scores,
        and categorical sentiment labels.
        """
        df = reviews_df.copy()
        print("Cleaning review text and computing sentiment scores...")

        df["cleaned_text"] = df["review_text"].apply(self.preprocess_text)

        sentiment_results = df["review_text"].apply(self.score_sentiment)
        df["sentiment_compound"] = [res["compound"] for res in sentiment_results]
        df["sentiment_pos"] = [res["pos"] for res in sentiment_results]
        df["sentiment_neu"] = [res["neu"] for res in sentiment_results]
        df["sentiment_neg"] = [res["neg"] for res in sentiment_results]
        df["sentiment_label"] = [res["label"] for res in sentiment_results]

        # Fit TF-IDF on cleaned reviews
        valid_texts = df["cleaned_text"][df["cleaned_text"].str.strip() != ""]
        if len(valid_texts) > 0:
            self.tfidf_vectorizer.fit(valid_texts)
            self.is_fitted = True

        return df

    def compute_movie_sentiment_aggregates(self, reviews_df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculates aggregate movie sentiment profiles:
        - Total review count
        - Average compound score
        - Positive, Neutral, Negative proportions
        - Sentiment-based recommendation boost factor (0.0 to 1.0)
        """
        if "sentiment_compound" not in reviews_df.columns:
            reviews_df = self.process_reviews_dataframe(reviews_df)

        grouped = reviews_df.groupby("movieId")

        aggregates = []
        for movie_id, group in grouped:
            total_reviews = len(group)
            avg_compound = float(group["sentiment_compound"].mean())
            pos_ratio = float((group["sentiment_label"] == "Positive").mean())
            neu_ratio = float((group["sentiment_label"] == "Neutral").mean())
            neg_ratio = float((group["sentiment_label"] == "Negative").mean())

            # Normalized sentiment score between 0.0 and 1.0
            # VADER compound is [-1, 1], so (compound + 1) / 2
            normalized_sentiment = (avg_compound + 1.0) / 2.0

            # Confidence weighting based on review sample size
            confidence_factor = min(1.0, total_reviews / 5.0)

            aggregates.append({
                "movieId": movie_id,
                "review_count": total_reviews,
                "avg_sentiment_compound": round(avg_compound, 4),
                "pos_review_ratio": round(pos_ratio, 4),
                "neu_review_ratio": round(neu_ratio, 4),
                "neg_review_ratio": round(neg_ratio, 4),
                "normalized_sentiment": round(normalized_sentiment, 4),
                "sentiment_confidence": round(confidence_factor, 4),
            })

        return pd.DataFrame(aggregates)

    def analyze_custom_review(self, text: str) -> Dict[str, Any]:
        """Real-time sentiment and NLP diagnostic for arbitrary user review text."""
        cleaned = self.preprocess_text(text)
        scores = self.score_sentiment(text)
        tokens = cleaned.split() if cleaned else []

        top_keywords = []
        if self.is_fitted and cleaned:
            vec = self.tfidf_vectorizer.transform([cleaned])
            feature_names = self.tfidf_vectorizer.get_feature_names_out()
            dense = vec.toarray()[0]
            top_indices = dense.argsort()[::-1][:5]
            top_keywords = [feature_names[i] for i in top_indices if dense[i] > 0]

        return {
            "original_text": text,
            "cleaned_text": cleaned,
            "token_count": len(tokens),
            "tokens": tokens,
            "scores": scores,
            "top_keywords": top_keywords,
        }

    def save_model(self, filename: str = "sentiment_pipeline.joblib") -> str:
        """Persists sentiment pipeline objects using Joblib."""
        save_path = os.path.join(self.models_dir, filename)
        payload = {
            "tfidf_vectorizer": self.tfidf_vectorizer,
            "is_fitted": self.is_fitted,
        }
        joblib.dump(payload, save_path)
        print(f"Sentiment pipeline saved successfully to {save_path}")
        return save_path

    def load_model(self, filename: str = "sentiment_pipeline.joblib") -> bool:
        """Loads persisted pipeline components."""
        load_path = os.path.join(self.models_dir, filename)
        if not os.path.exists(load_path):
            return False
        payload = joblib.load(load_path)
        self.tfidf_vectorizer = payload["tfidf_vectorizer"]
        self.is_fitted = payload["is_fitted"]
        print(f"Sentiment pipeline loaded from {load_path}")
        return True


if __name__ == "__main__":
    print("Testing SentimentAnalysisEngine module...")
    from preprocessing import DataPreprocessor

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    engine = SentimentAnalysisEngine()
    processed_reviews = engine.process_reviews_dataframe(data["reviews"])
    print(f"Processed {len(processed_reviews)} reviews.")
    print("\nSentiment label counts:")
    print(processed_reviews["sentiment_label"].value_counts())

    movie_sentiments = engine.compute_movie_sentiment_aggregates(processed_reviews)
    print(f"\nComputed aggregates for {len(movie_sentiments)} movies.")
    print(movie_sentiments.head(3))

    # Test single review diagnosis
    sample = "The direction was astonishing and emotionally powerful, though slightly long!"
    diagnosis = engine.analyze_custom_review(sample)
    print(f"\nDiagnostic for sample: '{sample}'")
    print(f"Label: {diagnosis['scores']['label']}, Compound: {diagnosis['scores']['compound']:.4f}")
    print(f"Keywords: {diagnosis['top_keywords']}")

    # Save pipeline
    engine.save_model()
