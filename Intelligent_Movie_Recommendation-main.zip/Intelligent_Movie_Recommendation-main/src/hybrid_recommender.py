"""
Intelligent Movie Recommendation System
Module 5: Hybrid Recommendation Engine
---------------------------------------
Fuses Content-Based similarity, Collaborative Filtering (SVD),
Movie Popularity (Bayesian Weighted Rating), and NLP Review Sentiment
with configurable weights, cold-start fallbacks, and explainable recommendations.
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional

from content_recommender import ContentBasedRecommender
from collaborative_filter import CollaborativeFilteringSVD
from sentiment_analysis import SentimentAnalysisEngine


class HybridRecommenderEngine:
    """
    Unified Hybrid Recommendation System combining:
    1. Collaborative Filtering (SVD predicted rating)
    2. Content-Based Profile Similarity (TF-IDF Cosine Similarity)
    3. Popularity & Quality (Bayesian Weighted Rating)
    4. NLP Review Sentiment (VADER compound & positive review ratio)
    """

    def __init__(
        self,
        cf_model: CollaborativeFilteringSVD = None,
        cb_model: ContentBasedRecommender = None,
        sentiment_engine: SentimentAnalysisEngine = None,
        models_dir: str = None
    ):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        self.cf_model = cf_model or CollaborativeFilteringSVD(models_dir=self.models_dir)
        self.cb_model = cb_model or ContentBasedRecommender(models_dir=self.models_dir)
        self.sentiment_engine = sentiment_engine or SentimentAnalysisEngine(models_dir=self.models_dir)

        # Default configurable weights
        self.weights = {
            "collaborative": 0.40,
            "content": 0.30,
            "popularity": 0.15,
            "sentiment": 0.15,
        }

        self.movies_df = None
        self.ratings_df = None
        self.movie_sentiments_df = None
        self.sentiment_map = {}
        self.is_fitted = False

    def set_weights(self, w_cf: float, w_cb: float, w_pop: float, w_sent: float):
        """Sets custom component weights and normalizes them to sum to 1.0."""
        total = w_cf + w_cb + w_pop + w_sent
        if total <= 0:
            raise ValueError("Sum of weights must be greater than 0.")
        self.weights = {
            "collaborative": w_cf / total,
            "content": w_cb / total,
            "popularity": w_pop / total,
            "sentiment": w_sent / total,
        }

    def fit(
        self,
        movies_df: pd.DataFrame,
        ratings_df: pd.DataFrame,
        reviews_df: pd.DataFrame,
        train_ratings_df: pd.DataFrame = None
    ):
        """Fits all sub-models and compiles sentiment lookup tables."""
        self.movies_df = movies_df.copy()
        self.ratings_df = ratings_df.copy()

        train_data = train_ratings_df if train_ratings_df is not None else ratings_df

        print("Fitting Collaborative Filtering model...")
        self.cf_model.fit(train_data, self.movies_df)

        print("Fitting Content-Based model...")
        self.cb_model.fit(self.movies_df, reviews_df)

        print("Computing Review Sentiment aggregates...")
        processed_reviews = self.sentiment_engine.process_reviews_dataframe(reviews_df)
        self.movie_sentiments_df = self.sentiment_engine.compute_movie_sentiment_aggregates(processed_reviews)

        # Build sentiment lookup map
        for _, row in self.movie_sentiments_df.iterrows():
            mid = int(row["movieId"])
            self.sentiment_map[mid] = {
                "avg_compound": row["avg_sentiment_compound"],
                "normalized": row["normalized_sentiment"],
                "pos_ratio": row["pos_review_ratio"],
                "review_count": int(row["review_count"]),
            }

        self.is_fitted = True
        print("Hybrid Recommendation Engine successfully fitted!")

    def _generate_explanation(
        self,
        movie_title: str,
        genres: str,
        pred_rating: float,
        content_score: float,
        sentiment_info: Optional[Dict[str, Any]],
        user_top_genres: List[str]
    ) -> str:
        """Constructs an intuitive, human-readable reason for the recommendation."""
        reasons = []

        # Genre alignment
        matched_genres = [g for g in user_top_genres if g.lower() in genres.lower()]
        if matched_genres:
            reasons.append(f"matches your interest in {', '.join(matched_genres[:2])}")

        # Collaborative confidence
        if pred_rating >= 4.0:
            reasons.append(f"users with similar taste rated it high ({pred_rating:.1f}★)")

        # Sentiment evidence
        if sentiment_info and sentiment_info.get("review_count", 0) > 0:
            pos_pct = int(sentiment_info.get("pos_ratio", 0) * 100)
            if pos_pct >= 60:
                reasons.append(f"{pos_pct}% positive audience reviews")

        # Fallback if no strong signals
        if not reasons:
            reasons.append(f"strong overall critical and audience consensus")

        return f"Recommended because it {' and '.join(reasons)}."

    def recommend_hybrid(
        self,
        user_id: int,
        top_n: int = 10,
        candidate_pool_size: int = 200,
        favorite_genres: List[str] = None,
        ratings_df: pd.DataFrame = None
    ) -> List[Dict[str, Any]]:
        """
        Produces top hybrid recommendations with full scores, predicted ratings,
        and explanations for any user (existing or cold-start).
        """
        if not self.is_fitted:
            raise RuntimeError("Hybrid engine must be fitted before generating recommendations.")

        # Identify existing user status
        r_df = ratings_df if ratings_df is not None else self.ratings_df
        if r_df is not None and not r_df.empty:
            user_ratings = r_df[r_df["userId"] == user_id]
        else:
            user_ratings = pd.DataFrame()
        is_cold_user = user_ratings.empty
        seen_movies = set(user_ratings["movieId"].unique()) if not is_cold_user else set()

        # Determine user's top genres from history or manual input
        user_top_genres = []
        if not is_cold_user:
            high_rated = user_ratings[user_ratings["rating"] >= 3.5].merge(self.movies_df, on="movieId")
            all_u_genres = []
            for g_str in high_rated["genres"]:
                for g in str(g_str).split("|"):
                    if g.strip() and g.strip() != "Unknown":
                        all_u_genres.append(g.strip())
            if all_u_genres:
                user_top_genres = pd.Series(all_u_genres).value_counts().head(3).index.tolist()
        elif favorite_genres:
            user_top_genres = favorite_genres

        # Adapt weights for cold start
        if is_cold_user:
            w_cf = 0.0
            w_cb = 0.40 if user_top_genres else 0.15
            w_pop = 0.35 if user_top_genres else 0.50
            w_sent = 0.25 if user_top_genres else 0.35
        else:
            w_cf = self.weights["collaborative"]
            w_cb = self.weights["content"]
            w_pop = self.weights["popularity"]
            w_sent = self.weights["sentiment"]

        # Select candidate items: top popular and content-relevant items
        candidates = self.movies_df[~self.movies_df["movieId"].isin(seen_movies)].copy()
        # Sort by weighted rating first to filter candidate pool
        candidates = candidates.sort_values(by="weighted_rating", ascending=False).head(candidate_pool_size)

        # Get content profile similarity scores if user has history
        content_sim_map = {}
        if not is_cold_user:
            cb_recs = self.cb_model.get_user_content_profile_recommendations(
                user_ratings, top_n=candidate_pool_size
            )
            for r in cb_recs:
                content_sim_map[r["movieId"]] = r["content_score"]

        scored_candidates = []
        for _, row in candidates.iterrows():
            mid = int(row["movieId"])
            title = str(row["title"])
            clean_title = str(row.get("clean_title", title))
            genres = str(row.get("genres", ""))
            year = row.get("year", None)
            wr = float(row.get("weighted_rating", 3.5))

            # 1. Collaborative filtering score [0, 1]
            pred_rating = self.cf_model.predict_rating(user_id, mid)
            cf_norm = (pred_rating - 0.5) / 4.5

            # 2. Content similarity score [0, 1]
            if not is_cold_user:
                cb_score = content_sim_map.get(mid, 0.0)
            else:
                # Cold-user genre match score
                match_count = sum(1 for g in user_top_genres if g.lower() in genres.lower())
                cb_score = min(1.0, match_count * 0.4)
            cb_norm = np.clip(cb_score, 0.0, 1.0)

            # 3. Popularity / Bayesian quality score [0, 1]
            pop_norm = np.clip((wr - 0.5) / 4.5, 0.0, 1.0)

            # 4. Sentiment score [0, 1]
            sent_info = self.sentiment_map.get(mid, None)
            if sent_info:
                sent_norm = sent_info["normalized"]
            else:
                # Prior neutral sentiment with slight baseline from rating
                sent_norm = pop_norm

            # Composite hybrid score
            hybrid_score = (
                w_cf * cf_norm
                + w_cb * cb_norm
                + w_pop * pop_norm
                + w_sent * sent_norm
            )

            # Recommendation explanation
            explanation = self._generate_explanation(
                movie_title=title,
                genres=genres,
                pred_rating=pred_rating,
                content_score=cb_score,
                sentiment_info=sent_info,
                user_top_genres=user_top_genres
            )

            scored_candidates.append({
                "movieId": mid,
                "title": title,
                "clean_title": clean_title,
                "genres": genres,
                "year": year,
                "predicted_rating": round(pred_rating, 2),
                "hybrid_score": round(float(hybrid_score), 4),
                "cf_score": round(float(cf_norm), 4),
                "content_score": round(float(cb_norm), 4),
                "popularity_score": round(float(pop_norm), 4),
                "sentiment_score": round(float(sent_norm), 4),
                "rating_mean": round(float(row.get("rating_mean", 0.0)), 2),
                "rating_count": int(row.get("rating_count", 0)),
                "explanation": explanation,
            })

        # Rank descending by hybrid score
        scored_candidates.sort(key=lambda x: x["hybrid_score"], reverse=True)
        return scored_candidates[:top_n]

    def save_model(self, filename: str = "hybrid_recommender.joblib") -> str:
        """Persists hybrid recommender configuration and metadata."""
        save_path = os.path.join(self.models_dir, filename)
        # Ensure sub-models are saved
        self.cf_model.save_model()
        self.cb_model.save_model()
        self.sentiment_engine.save_model()

        payload = {
            "weights": self.weights,
            "sentiment_map": self.sentiment_map,
            "movie_sentiments_df": self.movie_sentiments_df,
            "movies_df": self.movies_df,
            "ratings_df": self.ratings_df,
            "is_fitted": self.is_fitted,
        }
        joblib.dump(payload, save_path)
        print(f"Hybrid recommender saved successfully to {save_path}")
        return save_path

    def load_model(self, filename: str = "hybrid_recommender.joblib") -> bool:
        """Loads persisted hybrid configuration and sub-models."""
        save_path = os.path.join(self.models_dir, filename)
        if not os.path.exists(save_path):
            return False

        self.cf_model.load_model()
        self.cb_model.load_model()
        self.sentiment_engine.load_model()

        payload = joblib.load(save_path)
        self.weights = payload["weights"]
        self.sentiment_map = payload["sentiment_map"]
        self.movie_sentiments_df = payload["movie_sentiments_df"]
        self.movies_df = payload["movies_df"]
        self.ratings_df = payload.get("ratings_df", None)
        self.is_fitted = payload["is_fitted"]
        print(f"Hybrid recommender loaded from {save_path}")
        return True


if __name__ == "__main__":
    print("Testing HybridRecommenderEngine module...")
    from preprocessing import DataPreprocessor

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    engine = HybridRecommenderEngine()
    engine.fit(
        movies_df=data["movies"],
        ratings_df=data["ratings"],
        reviews_df=data["reviews"],
        train_ratings_df=data["train_ratings"]
    )

    # Test for User 1
    print("\n--- Top 5 Hybrid Recommendations for Existing User (User ID: 1) ---")
    u1_recs = engine.recommend_hybrid(user_id=1, top_n=5)
    for i, rec in enumerate(u1_recs, 1):
        print(f"{i}. {rec['title']} ({rec['genres']})")
        print(f"   Hybrid Score: {rec['hybrid_score']:.4f} | Predicted: {rec['predicted_rating']}★")
        print(f"   Reason: {rec['explanation']}\n")

    # Test for Cold Start User (User ID: 99999) with preferred genres
    print("--- Top 5 Hybrid Recommendations for Cold-Start User (Genres: Sci-Fi, Action) ---")
    cold_recs = engine.recommend_hybrid(user_id=99999, top_n=5, favorite_genres=["Sci-Fi", "Action"])
    for i, rec in enumerate(cold_recs, 1):
        print(f"{i}. {rec['title']} ({rec['genres']})")
        print(f"   Hybrid Score: {rec['hybrid_score']:.4f} | Predicted: {rec['predicted_rating']}★")
        print(f"   Reason: {rec['explanation']}\n")

    # Save complete hybrid pipeline
    engine.save_model()
