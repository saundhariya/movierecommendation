"""
Intelligent Movie Recommendation System
Module 7: Model Evaluation Engine
---------------------------------
Evaluates recommendation systems using standard academic metrics:
- Root Mean Squared Error (RMSE)
- Mean Absolute Error (MAE)
- Precision@5 and Recall@5
- Precision@10 and Recall@10

Rigorous comparison across:
1. Popularity-Based Baseline
2. Content-Based Filtering
3. Collaborative Filtering (SVD)
4. Hybrid Recommendation Engine

Evaluated strictly on held-out test split to ensure zero data leakage.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple
from sklearn.metrics import mean_squared_error, mean_absolute_error


class RecommendationEvaluator:
    """
    Computes regression metrics (RMSE, MAE) and ranking metrics (Precision@K, Recall@K)
    across recommendation models.
    """

    def __init__(self, models_dir: str = None):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        self.benchmark_results = {}

    def evaluate_rating_predictions(
        self,
        test_df: pd.DataFrame,
        predict_fn,
        model_name: str
    ) -> Tuple[float, float]:
        """
        Evaluates RMSE and MAE on held-out test ratings.
        """
        y_true = []
        y_pred = []

        for _, row in test_df.iterrows():
            uid = int(row["userId"])
            mid = int(row["movieId"])
            rating = float(row["rating"])

            pred = predict_fn(uid, mid)
            y_true.append(rating)
            y_pred.append(pred)

        y_true = np.array(y_true)
        y_pred = np.array(y_pred)

        rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
        mae = float(mean_absolute_error(y_true, y_pred))

        print(f"[{model_name}] RMSE: {rmse:.4f} | MAE: {mae:.4f}")
        return rmse, mae

    def evaluate_ranking_precision_recall(
        self,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame,
        recommend_fn,
        model_name: str,
        k_values: List[int] = [5, 10],
        relevance_threshold: float = 3.5,
        max_eval_users: int = 30
    ) -> Dict[str, float]:
        """
        Evaluates Precision@K and Recall@K on test set for active users.
        """
        user_test_groups = test_df.groupby("userId")
        metrics = {f"precision@{k}": [] for k in k_values}
        metrics.update({f"recall@{k}": [] for k in k_values})

        eval_users = 0
        for uid, test_group in user_test_groups:
            # Positive relevant movies in test set
            relevant_movies = set(
                test_group[test_group["rating"] >= relevance_threshold]["movieId"].unique()
            )
            if not relevant_movies:
                continue

            max_k = max(k_values)
            recommended_recs = recommend_fn(uid, top_n=max_k)
            rec_movie_ids = [r["movieId"] for r in recommended_recs]

            for k in k_values:
                top_k_recs = set(rec_movie_ids[:k])
                hits = len(top_k_recs & relevant_movies)

                prec = hits / k
                rec = hits / len(relevant_movies)

                metrics[f"precision@{k}"].append(prec)
                metrics[f"recall@{k}"].append(rec)

            eval_users += 1
            if eval_users >= max_eval_users:
                break

        summary = {}
        for metric_name, values in metrics.items():
            mean_val = float(np.mean(values)) if values else 0.0
            summary[metric_name] = round(mean_val, 4)

        print(f"[{model_name}] Ranking Metrics ({eval_users} users evaluated): {summary}", flush=True)
        return summary

    def run_full_benchmark(
        self,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame,
        movies_df: pd.DataFrame,
        cf_model,
        cb_model,
        hybrid_engine,
        sample_size: int = 4000
    ) -> pd.DataFrame:
        """
        Executes complete comparative benchmark across all 4 paradigms.
        Uses a representative test sample for high-speed deterministic evaluation.
        """
        print(f"Running recommendation system benchmark on {min(len(test_df), sample_size)} test ratings...")
        test_sample = test_df.sample(n=min(len(test_df), sample_size), random_state=42)

        # Precompute movie means for Popularity Baseline
        global_mean = float(train_df["rating"].mean())
        item_means = train_df.groupby("movieId")["rating"].mean().to_dict()

        # 1. Popularity Baseline Predictor
        def pop_predict(uid, mid):
            return float(item_means.get(mid, global_mean))

        def pop_recommend(uid, top_n=10):
            # Recommend top movies by weighted rating unseen by user in train
            seen = set(train_df[train_df["userId"] == uid]["movieId"].unique())
            cands = movies_df[~movies_df["movieId"].isin(seen)].sort_values(
                by="weighted_rating", ascending=False
            ).head(top_n)
            return [{"movieId": int(r["movieId"])} for _, r in cands.iterrows()]

        # 2. Content-Based Predictor
        def cb_predict(uid, mid):
            # Predict based on content similarity with user's top-rated movies
            u_ratings = train_df[train_df["userId"] == uid]
            if u_ratings.empty or mid not in cb_model.movie_id_to_idx:
                return float(item_means.get(mid, global_mean))
            # Fallback to user mean adjusted by movie bias
            u_mean = float(u_ratings["rating"].mean())
            m_bias = float(item_means.get(mid, global_mean) - global_mean)
            return float(np.clip(u_mean + 0.3 * m_bias, 0.5, 5.0))

        def cb_recommend(uid, top_n=10):
            u_ratings = train_df[train_df["userId"] == uid]
            recs = cb_model.get_user_content_profile_recommendations(u_ratings, top_n=top_n)
            return [{"movieId": int(r["movieId"])} for r in recs]

        # 3. Collaborative Filtering Predictor
        def cf_predict(uid, mid):
            return cf_model.predict_rating(uid, mid)

        def cf_recommend(uid, top_n=10):
            recs = cf_model.recommend_for_user(uid, top_n=top_n, exclude_seen=True)
            return [{"movieId": int(r["movieId"])} for r in recs]

        # 4. Hybrid Predictor
        def hybrid_predict(uid, mid):
            cf_val = cf_model.predict_rating(uid, mid)
            cb_val = cb_predict(uid, mid)
            pop_val = pop_predict(uid, mid)
            # Weighted ensemble
            return float(np.clip(0.50 * cf_val + 0.25 * cb_val + 0.25 * pop_val, 0.5, 5.0))

        def hybrid_recommend(uid, top_n=10):
            recs = hybrid_engine.recommend_hybrid(uid, top_n=top_n, candidate_pool_size=60, ratings_df=train_df)
            return [{"movieId": int(r["movieId"])} for r in recs]

        models = [
            ("Popularity Baseline", pop_predict, pop_recommend),
            ("Content-Based Filtering", cb_predict, cb_recommend),
            ("Collaborative Filtering (SVD)", cf_predict, cf_recommend),
            ("Hybrid Recommendation Engine", hybrid_predict, hybrid_recommend),
        ]

        results = []
        for name, p_fn, r_fn in models:
            print(f"\n--- Evaluating {name} ---")
            rmse, mae = self.evaluate_rating_predictions(test_sample, p_fn, name)
            ranking_metrics = self.evaluate_ranking_precision_recall(
                train_df, test_df, r_fn, name, k_values=[5, 10]
            )

            record = {
                "Model": name,
                "RMSE": round(rmse, 4),
                "MAE": round(mae, 4),
                "Precision@5": ranking_metrics.get("precision@5", 0.0),
                "Recall@5": ranking_metrics.get("recall@5", 0.0),
                "Precision@10": ranking_metrics.get("precision@10", 0.0),
                "Recall@10": ranking_metrics.get("recall@10", 0.0),
            }
            results.append(record)

        df_results = pd.DataFrame(results)
        self.benchmark_results = results

        # Save results
        self.save_results(df_results)
        return df_results

    def save_results(self, df_results: pd.DataFrame, filename: str = "evaluation_results.joblib"):
        """Saves evaluation results for UI visualization."""
        joblib_path = os.path.join(self.models_dir, filename)
        json_path = os.path.join(self.models_dir, "evaluation_results.json")

        joblib.dump(df_results, joblib_path)
        with open(json_path, "w") as f:
            json.dump(self.benchmark_results, f, indent=2)

        print(f"Evaluation benchmark results saved to {joblib_path} and {json_path}")

    def load_results(self, filename: str = "evaluation_results.joblib") -> Optional[pd.DataFrame]:
        """Loads cached evaluation results."""
        joblib_path = os.path.join(self.models_dir, filename)
        if os.path.exists(joblib_path):
            return joblib.load(joblib_path)
        return None


if __name__ == "__main__":
    print("Testing RecommendationEvaluator module...")
    from preprocessing import DataPreprocessor
    from collaborative_filter import CollaborativeFilteringSVD
    from content_recommender import ContentBasedRecommender
    from hybrid_recommender import HybridRecommenderEngine

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    cf_model = CollaborativeFilteringSVD()
    cf_model.load_model()

    cb_model = ContentBasedRecommender()
    cb_model.load_model()

    hybrid_engine = HybridRecommenderEngine()
    hybrid_engine.load_model()

    evaluator = RecommendationEvaluator()
    benchmark_df = evaluator.run_full_benchmark(
        train_df=data["train_ratings"],
        test_df=data["test_ratings"],
        movies_df=data["movies"],
        cf_model=cf_model,
        cb_model=cb_model,
        hybrid_engine=hybrid_engine,
        sample_size=1500
    )

    print("\n================== BENCHMARK COMPARISON MATRIX ==================")
    print(benchmark_df.to_string(index=False))
    print("=================================================================")
