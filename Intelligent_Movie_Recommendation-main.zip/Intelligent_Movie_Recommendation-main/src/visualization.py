"""
Intelligent Movie Recommendation System
Module 8: Data Visualization & Analytical Plotting
--------------------------------------------------
Generates publication-quality charts using Matplotlib and Seaborn
with cinematic dark-theme styling:
1. Movie rating distribution histogram with KDE.
2. Review sentiment distribution (Positive / Neutral / Negative).
3. Most popular movie genres bar chart.
4. RMSE and MAE model performance comparison chart.
5. Precision@K and Recall@K ranking metrics comparison.
"""

import os
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for headless / server environments
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from typing import Optional

# Cinematic Dark Theme Palette
DARK_BG = "#0B0F19"
PANEL_BG = "#151C2C"
TEXT_COLOR = "#F1F5F9"
ACCENT_PURPLE = "#8B5CF6"
ACCENT_BLUE = "#38BDF8"
ACCENT_GREEN = "#10B981"
ACCENT_AMBER = "#F59E0B"
ACCENT_RED = "#EF4444"


def apply_cinematic_theme():
    """Applies a consistent dark cinematic visual theme across all plots."""
    plt.style.use("dark_background")
    plt.rcParams.update({
        "figure.facecolor": DARK_BG,
        "axes.facecolor": PANEL_BG,
        "axes.edgecolor": "#334155",
        "axes.labelcolor": TEXT_COLOR,
        "xtick.color": "#94A3B8",
        "ytick.color": "#94A3B8",
        "text.color": TEXT_COLOR,
        "grid.color": "#1E293B",
        "grid.linestyle": "--",
        "grid.alpha": 0.6,
        "font.family": "sans-serif",
    })


def plot_rating_distribution(ratings_df: pd.DataFrame) -> plt.Figure:
    """
    Graph 1: Movie rating distribution histogram with KDE overlay.
    """
    apply_cinematic_theme()
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=120)

    ratings = ratings_df["rating"].dropna()
    mean_val = ratings.mean()
    median_val = ratings.median()

    # Histogram with KDE
    sns.histplot(
        ratings,
        bins=10,
        kde=True,
        color=ACCENT_BLUE,
        edgecolor=PANEL_BG,
        alpha=0.75,
        ax=ax,
    )

    ax.axvline(mean_val, color=ACCENT_AMBER, linestyle="--", linewidth=2, label=f"Mean: {mean_val:.2f}★")
    ax.axvline(median_val, color=ACCENT_GREEN, linestyle=":", linewidth=2, label=f"Median: {median_val:.2f}★")

    ax.set_title("Distribution of User Movie Ratings", fontsize=14, fontweight="bold", pad=12, color=TEXT_COLOR)
    ax.set_xlabel("Rating Scale (0.5 to 5.0 Stars)", fontsize=11, labelpad=8)
    ax.set_ylabel("Total Number of Ratings", fontsize=11, labelpad=8)
    ax.set_xticks(np.arange(0.5, 5.5, 0.5))
    ax.legend(frameon=True, facecolor=PANEL_BG, edgecolor="#334155")
    ax.grid(axis="y")

    plt.tight_layout()
    return fig


def plot_sentiment_distribution(reviews_df: pd.DataFrame) -> plt.Figure:
    """
    Graph 2: Sentiment distribution breakdown (Positive, Neutral, Negative).
    """
    apply_cinematic_theme()
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5), dpi=120)

    counts = reviews_df["sentiment_label"].value_counts()
    colors = {
        "Positive": ACCENT_GREEN,
        "Neutral": ACCENT_BLUE,
        "Negative": ACCENT_RED,
    }
    palette = [colors.get(label, ACCENT_PURPLE) for label in counts.index]

    # Donut Chart
    wedges, texts, autotexts = ax1.pie(
        counts.values,
        labels=counts.index,
        autopct="%1.1f%%",
        startangle=140,
        colors=palette,
        wedgeprops=dict(width=0.45, edgecolor=DARK_BG, linewidth=2),
        textprops=dict(color=TEXT_COLOR, fontsize=10, fontweight="bold"),
    )
    for at in autotexts:
        at.set_color("#FFFFFF")
    ax1.set_title("Sentiment Proportions", fontsize=13, fontweight="bold", pad=10)

    # Compound Score Distribution
    if "sentiment_compound" in reviews_df.columns:
        sns.kdeplot(
            reviews_df["sentiment_compound"],
            fill=True,
            color=ACCENT_PURPLE,
            alpha=0.6,
            ax=ax2
        )
        ax2.axvline(0.05, color=ACCENT_GREEN, linestyle="--", alpha=0.7, label="Pos Threshold (≥ 0.05)")
        ax2.axvline(-0.05, color=ACCENT_RED, linestyle="--", alpha=0.7, label="Neg Threshold (≤ -0.05)")
        ax2.set_title("VADER Compound Score KDE", fontsize=13, fontweight="bold", pad=10)
        ax2.set_xlabel("Compound Polarity (-1.0 to +1.0)", fontsize=10)
        ax2.set_ylabel("Density", fontsize=10)
        ax2.legend(frameon=True, facecolor=PANEL_BG, edgecolor="#334155", fontsize=9)
        ax2.grid(True)

    plt.tight_layout()
    return fig


def plot_genre_popularity(movies_df: pd.DataFrame, top_n: int = 12) -> plt.Figure:
    """
    Graph 3: Most popular movie genres ranked by count.
    """
    apply_cinematic_theme()
    fig, ax = plt.subplots(figsize=(9, 5), dpi=120)

    genre_counts = {}
    for g_str in movies_df["genres"]:
        for g in str(g_str).split("|"):
            g = g.strip()
            if g and g != "Unknown":
                genre_counts[g] = genre_counts.get(g, 0) + 1

    series = pd.Series(genre_counts).sort_values(ascending=True).tail(top_n)

    # Horizontal Bar Chart
    bars = ax.barh(series.index, series.values, color=ACCENT_PURPLE, edgecolor=PANEL_BG, height=0.65, alpha=0.85)

    # Bar label values
    for bar in bars:
        w = bar.get_width()
        ax.text(w + 15, bar.get_y() + bar.get_height() / 2, f"{int(w):,}",
                ha="left", va="center", color="#94A3B8", fontsize=9, fontweight="bold")

    ax.set_title(f"Top {top_n} Most Frequent Movie Genres in Catalog", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Number of Movies in Dataset", fontsize=11, labelpad=8)
    ax.set_xlim(0, max(series.values) * 1.15)
    ax.grid(axis="x")

    plt.tight_layout()
    return fig


def plot_model_comparison(benchmark_df: pd.DataFrame) -> plt.Figure:
    """
    Graph 4: RMSE and MAE model performance comparison chart.
    """
    apply_cinematic_theme()
    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=120)

    df = benchmark_df.copy()
    models = df["Model"].tolist()
    x = np.arange(len(models))
    width = 0.35

    # Grouped bars
    rects1 = ax.bar(x - width / 2, df["RMSE"], width, label="RMSE (Root Mean Sq Error)",
                    color=ACCENT_PURPLE, edgecolor=PANEL_BG, alpha=0.9)
    rects2 = ax.bar(x + width / 2, df["MAE"], width, label="MAE (Mean Absolute Error)",
                    color=ACCENT_BLUE, edgecolor=PANEL_BG, alpha=0.9)

    # Add numeric labels on top of bars
    for bar in rects1:
        h = bar.get_height()
        ax.annotate(f"{h:.3f}", xy=(bar.get_x() + bar.get_width() / 2, h),
                    xytext=(0, 4), textcoords="offset points", ha="center", va="bottom",
                    fontsize=9, fontweight="bold", color=TEXT_COLOR)

    for bar in rects2:
        h = bar.get_height()
        ax.annotate(f"{h:.3f}", xy=(bar.get_x() + bar.get_width() / 2, h),
                    xytext=(0, 4), textcoords="offset points", ha="center", va="bottom",
                    fontsize=9, fontweight="bold", color=TEXT_COLOR)

    ax.set_title("Model Error Comparison (Lower is Better)", fontsize=14, fontweight="bold", pad=14)
    ax.set_ylabel("Error Metric Value", fontsize=11, labelpad=8)
    ax.set_xticks(x)
    ax.set_xticklabels([m.replace(" ", "\n") for m in models], fontsize=10)
    ax.set_ylim(0, max(df["RMSE"].max(), df["MAE"].max()) * 1.25)
    ax.legend(frameon=True, facecolor=PANEL_BG, edgecolor="#334155")
    ax.grid(axis="y")

    plt.tight_layout()
    return fig


def plot_ranking_metrics_comparison(benchmark_df: pd.DataFrame) -> plt.Figure:
    """
    Graph 5: Precision@K and Recall@K ranking comparison.
    """
    apply_cinematic_theme()
    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=120)

    df = benchmark_df.copy()
    models = df["Model"].tolist()
    x = np.arange(len(models))
    width = 0.20

    # 4 bars per model
    ax.bar(x - 1.5 * width, df["Precision@5"], width, label="Precision@5", color="#EC4899", alpha=0.85)
    ax.bar(x - 0.5 * width, df["Recall@5"], width, label="Recall@5", color="#8B5CF6", alpha=0.85)
    ax.bar(x + 0.5 * width, df["Precision@10"], width, label="Precision@10", color="#38BDF8", alpha=0.85)
    ax.bar(x + 1.5 * width, df["Recall@10"], width, label="Recall@10", color="#10B981", alpha=0.85)

    ax.set_title("Ranking Precision & Recall Across Recommender Models", fontsize=14, fontweight="bold", pad=14)
    ax.set_ylabel("Score (0.0 to 1.0)", fontsize=11, labelpad=8)
    ax.set_xticks(x)
    ax.set_xticklabels([m.replace(" ", "\n") for m in models], fontsize=10)
    ax.legend(frameon=True, facecolor=PANEL_BG, edgecolor="#334155", ncol=2)
    ax.grid(axis="y")

    plt.tight_layout()
    return fig


if __name__ == "__main__":
    print("Testing Visualizations module...")
    from preprocessing import DataPreprocessor
    from sentiment_analysis import SentimentAnalysisEngine
    from evaluation import RecommendationEvaluator

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    engine = SentimentAnalysisEngine()
    processed_reviews = engine.process_reviews_dataframe(data["reviews"])

    evaluator = RecommendationEvaluator()
    benchmark_df = evaluator.load_results()

    # Create charts output directory
    vis_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "visualizations")
    os.makedirs(vis_dir, exist_ok=True)

    fig1 = plot_rating_distribution(data["ratings"])
    fig1.savefig(os.path.join(vis_dir, "fig1_rating_distribution.png"))

    fig2 = plot_sentiment_distribution(processed_reviews)
    fig2.savefig(os.path.join(vis_dir, "fig2_sentiment_distribution.png"))

    fig3 = plot_genre_popularity(data["movies"])
    fig3.savefig(os.path.join(vis_dir, "fig3_genre_popularity.png"))

    if benchmark_df is not None:
        fig4 = plot_model_comparison(benchmark_df)
        fig4.savefig(os.path.join(vis_dir, "fig4_model_comparison.png"))

        fig5 = plot_ranking_metrics_comparison(benchmark_df)
        fig5.savefig(os.path.join(vis_dir, "fig5_ranking_metrics.png"))

    print(f"All visualization charts rendered and saved to {vis_dir}")
