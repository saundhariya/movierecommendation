"""
Intelligent Movie Recommendation System
Module 3: Content-Based Recommendation Engine
---------------------------------------------
Implements TF-IDF vectorization on combined movie metadata (genres, title tokens,
review sentiment keywords), cosine similarity matrix computation, and Top-N
content similarity recommendations.
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Union
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel


class ContentBasedRecommender:
    """
    Content-Based Filtering system utilizing TF-IDF and Cosine Similarity
    across movie genres, titles, and textual metadata.
    """

    def __init__(self, models_dir: str = None):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        self.tfidf_vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=10000,
            sublinear_tf=True
        )
        self.tfidf_matrix = None
        self.movies_df = None
        self.movie_id_to_idx = {}
        self.idx_to_movie_id = {}
        self.title_to_id = {}
        self.is_fitted = False

    def _prepare_metadata_corpus(self, movies_df: pd.DataFrame, reviews_df: pd.DataFrame = None) -> List[str]:
        """
        Combines genres, title tokens, and review summary keywords
        into a unified textual feature bag for each movie.
        """
        corpus = []

        # Optional review keywords per movie
        review_summaries = {}
        if reviews_df is not None and not reviews_df.empty:
            for mid, group in reviews_df.groupby("movieId"):
                combined_reviews = " ".join(group["review_text"].astype(str).tolist()[:5])
                review_summaries[mid] = combined_reviews

        for _, row in movies_df.iterrows():
            mid = row["movieId"]
            genres_clean = str(row.get("genres", "")).replace("|", " ")
            title_clean = str(row.get("clean_title", row.get("title", "")))
            year_str = f"year_{row.get('year', '')}" if pd.notna(row.get("year")) else ""

            # Boost genre importance by duplicating genres string
            movie_bag = f"{genres_clean} {genres_clean} {title_clean} {year_str}"

            if mid in review_summaries:
                movie_bag += f" {review_summaries[mid]}"

            corpus.append(movie_bag.strip())

        return corpus

    def fit(self, movies_df: pd.DataFrame, reviews_df: pd.DataFrame = None):
        """Fits TF-IDF vectorizer and builds index lookups."""
        self.movies_df = movies_df.copy().reset_index(drop=True)

        for idx, row in self.movies_df.iterrows():
            mid = int(row["movieId"])
            title = str(row["title"]).strip()
            clean_title = str(row.get("clean_title", title)).strip().lower()

            self.movie_id_to_idx[mid] = idx
            self.idx_to_movie_id[idx] = mid
            self.title_to_id[title.lower()] = mid
            self.title_to_id[clean_title] = mid

        corpus = self._prepare_metadata_corpus(self.movies_df, reviews_df)
        self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(corpus)
        self.is_fitted = True
        print(f"Content-Based Recommender fitted with matrix shape: {self.tfidf_matrix.shape}")

    def get_similar_movies(
        self,
        movie_identifier: Union[int, str],
        top_n: int = 10,
        genre_filter: str = None
    ) -> List[Dict[str, Any]]:
        """
        Calculates Top-N similar movies using Cosine Similarity.
        Supports movie ID or movie title as identifier.
        """
        if not self.is_fitted:
            raise RuntimeError("ContentBasedRecommender must be fitted before making recommendations.")

        # Resolve movie ID
        if isinstance(movie_identifier, str):
            clean_id_key = movie_identifier.strip().lower()
            if clean_id_key in self.title_to_id:
                target_mid = self.title_to_id[clean_id_key]
            else:
                # Fuzzy fallback: check substring match
                matches = self.movies_df[
                    self.movies_df["clean_title"].str.lower().str.contains(clean_id_key, regex=False, na=False)
                ]
                if not matches.empty:
                    target_mid = matches.iloc[0]["movieId"]
                else:
                    return []
        else:
            target_mid = int(movie_identifier)

        if target_mid not in self.movie_id_to_idx:
            return []

        target_idx = self.movie_id_to_idx[target_mid]
        target_vector = self.tfidf_matrix[target_idx]

        # Compute cosine similarity (linear_kernel is fast because vectors are L2-normalized)
        cosine_sims = linear_kernel(target_vector, self.tfidf_matrix).flatten()

        # Sort indices in descending order
        # Exclude the target movie itself
        sorted_indices = cosine_sims.argsort()[::-1]

        recommendations = []
        for idx in sorted_indices:
            if idx == target_idx:
                continue

            row = self.movies_df.iloc[idx]
            mid = int(row["movieId"])
            genres = str(row.get("genres", ""))

            # Apply genre filter if specified
            if genre_filter and genre_filter.lower() not in genres.lower():
                continue

            sim_score = float(cosine_sims[idx])
            recommendations.append({
                "movieId": mid,
                "title": row.get("title", ""),
                "clean_title": row.get("clean_title", ""),
                "genres": genres,
                "year": row.get("year", None),
                "similarity_score": round(sim_score, 4),
                "rating_mean": round(float(row.get("rating_mean", 0.0)), 2),
                "rating_count": int(row.get("rating_count", 0)),
                "weighted_rating": round(float(row.get("weighted_rating", 0.0)), 2),
            })

            if len(recommendations) >= top_n:
                break

        return recommendations

    def get_user_content_profile_recommendations(
        self,
        user_ratings_df: pd.DataFrame,
        top_n: int = 10,
        min_user_rating: float = 3.5
    ) -> List[Dict[str, Any]]:
        """
        Builds a user taste profile vector from highly rated movies
        and recommends similar unseen movies.
        """
        if not self.is_fitted:
            raise RuntimeError("Recommender is not fitted.")

        positive_ratings = user_ratings_df[user_ratings_df["rating"] >= min_user_rating]
        if positive_ratings.empty:
            positive_ratings = user_ratings_df

        seen_movie_ids = set(user_ratings_df["movieId"].unique())
        rated_indices = [
            (self.movie_id_to_idx[mid], float(r))
            for mid, r in zip(positive_ratings["movieId"], positive_ratings["rating"])
            if mid in self.movie_id_to_idx
        ]

        if not rated_indices:
            return []

        # Weighted user profile vector
        user_vector = np.zeros((1, self.tfidf_matrix.shape[1]))
        total_weight = 0.0

        for idx, rating in rated_indices:
            user_vector += rating * self.tfidf_matrix[idx].toarray()
            total_weight += rating

        if total_weight > 0:
            user_vector /= total_weight

        sim_scores = linear_kernel(user_vector, self.tfidf_matrix).flatten()
        sorted_indices = sim_scores.argsort()[::-1]

        recommendations = []
        for idx in sorted_indices:
            mid = self.idx_to_movie_id[idx]
            if mid in seen_movie_ids:
                continue

            row = self.movies_df.iloc[idx]
            recommendations.append({
                "movieId": mid,
                "title": row.get("title", ""),
                "genres": row.get("genres", ""),
                "content_score": round(float(sim_scores[idx]), 4),
                "rating_mean": round(float(row.get("rating_mean", 0.0)), 2),
                "rating_count": int(row.get("rating_count", 0)),
                "weighted_rating": round(float(row.get("weighted_rating", 0.0)), 2),
            })

            if len(recommendations) >= top_n:
                break

        return recommendations

    def save_model(self, filename: str = "content_recommender.joblib") -> str:
        """Persists content recommendation artifacts with Joblib."""
        save_path = os.path.join(self.models_dir, filename)
        payload = {
            "tfidf_vectorizer": self.tfidf_vectorizer,
            "tfidf_matrix": self.tfidf_matrix,
            "movies_df": self.movies_df,
            "movie_id_to_idx": self.movie_id_to_idx,
            "idx_to_movie_id": self.idx_to_movie_id,
            "title_to_id": self.title_to_id,
            "is_fitted": self.is_fitted,
        }
        joblib.dump(payload, save_path)
        print(f"Content recommender saved successfully to {save_path}")
        return save_path

    def load_model(self, filename: str = "content_recommender.joblib") -> bool:
        """Loads persisted content recommendation engine artifacts."""
        load_path = os.path.join(self.models_dir, filename)
        if not os.path.exists(load_path):
            return False
        payload = joblib.load(load_path)
        self.tfidf_vectorizer = payload["tfidf_vectorizer"]
        self.tfidf_matrix = payload["tfidf_matrix"]
        self.movies_df = payload["movies_df"]
        self.movie_id_to_idx = payload["movie_id_to_idx"]
        self.idx_to_movie_id = payload["idx_to_movie_id"]
        self.title_to_id = payload["title_to_id"]
        self.is_fitted = payload["is_fitted"]
        print(f"Content recommender loaded from {load_path}")
        return True


if __name__ == "__main__":
    print("Testing ContentBasedRecommender module...")
    from preprocessing import DataPreprocessor

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    content_model = ContentBasedRecommender()
    content_model.fit(data["movies"], data["reviews"])

    # Test top 5 similar to Toy Story (movieId 1)
    print("\nTop 5 similar movies to 'Toy Story (1995)':")
    recs = content_model.get_similar_movies(1, top_n=5)
    for i, r in enumerate(recs, 1):
        print(f"{i}. {r['title']} | Sim: {r['similarity_score']:.4f} | Genres: {r['genres']}")

    # Test user profile recommendations for user 1
    u1_ratings = data["ratings"][data["ratings"]["userId"] == 1]
    user_recs = content_model.get_user_content_profile_recommendations(u1_ratings, top_n=5)
    print("\nTop 5 user profile recommendations for User 1:")
    for i, r in enumerate(user_recs, 1):
        print(f"{i}. {r['title']} | Score: {r['content_score']:.4f} | Genres: {r['genres']}")

    # Save model
    content_model.save_model()
