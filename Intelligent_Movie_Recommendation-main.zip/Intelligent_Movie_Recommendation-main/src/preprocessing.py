"""
Intelligent Movie Recommendation System
Module 1: Data Preprocessing & Feature Engineering
--------------------------------------------------
Handles dataset ingestion, cleaning, normalization, genre feature extraction,
user-movie rating matrix creation, and train-test splitting.
"""

import os
import re
import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any


def get_default_dataset_paths(data_dir: str = None) -> Dict[str, str]:
    """Resolve absolute or relative paths to dataset files."""
    if data_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        data_dir = os.path.join(base_dir, "dataset")
    return {
        "movies": os.path.join(data_dir, "movies.csv"),
        "ratings": os.path.join(data_dir, "ratings.csv"),
        "links": os.path.join(data_dir, "links.csv"),
        "reviews": os.path.join(data_dir, "reviews.csv"),
    }


def extract_year_from_title(title: str) -> Tuple[str, int]:
    """
    Extracts release year from movie title strings like 'Toy Story (1995)'.
    Returns clean title and parsed year (or None if not found).
    """
    if not isinstance(title, str):
        return "", None
    match = re.search(r"\((\d{4})\)\s*$", title.strip())
    if match:
        year = int(match.group(1))
        clean_title = re.sub(r"\(\d{4}\)\s*$", "", title).strip()
        return clean_title, year
    return title.strip(), None


class DataPreprocessor:
    """
    Encapsulates all preprocessing and transformation logic for MovieLens
    and movie review datasets.
    """

    def __init__(self, data_dir: str = None):
        self.paths = get_default_dataset_paths(data_dir)
        self.movies_df = None
        self.ratings_df = None
        self.links_df = None
        self.reviews_df = None
        self.global_mean_rating = 0.0
        self.unique_genres = []

    def load_raw_data(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Loads CSV files with error handling and fallback checks."""
        for key, path in self.paths.items():
            if not os.path.exists(path):
                raise FileNotFoundError(f"Required dataset file not found: {path}")

        self.movies_df = pd.read_csv(self.paths["movies"])
        self.ratings_df = pd.read_csv(self.paths["ratings"])
        self.links_df = pd.read_csv(self.paths["links"])
        self.reviews_df = pd.read_csv(self.paths["reviews"])

        return self.movies_df, self.ratings_df, self.links_df, self.reviews_df

    def clean_datasets(self) -> None:
        """
        Cleans missing values, validates ratings, removes duplicates,
        and parses title/year attributes.
        """
        # 1. Clean movies
        self.movies_df = self.movies_df.drop_duplicates(subset=["movieId"])
        self.movies_df["genres"] = self.movies_df["genres"].fillna("Unknown")
        self.movies_df["genres"] = self.movies_df["genres"].replace("(no genres listed)", "Unknown")

        # Parse year and clean title
        titles_and_years = self.movies_df["title"].apply(extract_year_from_title)
        self.movies_df["clean_title"] = [t[0] for t in titles_and_years]
        self.movies_df["year"] = [t[1] for t in titles_and_years]

        # 2. Clean ratings
        self.ratings_df = self.ratings_df.drop_duplicates(subset=["userId", "movieId"])
        # Ensure ratings are valid numbers between 0.5 and 5.0
        self.ratings_df = self.ratings_df[
            (self.ratings_df["rating"] >= 0.5) & (self.ratings_df["rating"] <= 5.0)
        ].copy()
        self.ratings_df = self.ratings_df.dropna(subset=["userId", "movieId", "rating"])
        self.ratings_df["userId"] = self.ratings_df["userId"].astype(int)
        self.ratings_df["movieId"] = self.ratings_df["movieId"].astype(int)

        # 3. Clean links
        self.links_df = self.links_df.drop_duplicates(subset=["movieId"])
        self.links_df["movieId"] = self.links_df["movieId"].astype(int)
        if "imdbId" in self.links_df.columns:
            self.links_df["imdbId"] = self.links_df["imdbId"].apply(
                lambda x: f"tt{int(x):07d}" if pd.notna(x) else ""
            )

        # Merge links to movies
        self.movies_df = self.movies_df.merge(
            self.links_df[["movieId", "imdbId"]], on="movieId", how="left"
        )
        self.movies_df["imdbId"] = self.movies_df["imdbId"].fillna("")

        # 4. Clean reviews
        self.reviews_df = self.reviews_df.drop_duplicates(subset=["review_id"])
        self.reviews_df = self.reviews_df.dropna(subset=["movieId", "review_text"])
        self.reviews_df["movieId"] = self.reviews_df["movieId"].astype(int)
        self.reviews_df["review_text"] = self.reviews_df["review_text"].astype(str).str.strip()

        # Global average rating
        self.global_mean_rating = float(self.ratings_df["rating"].mean())

    def compute_movie_and_user_features(self) -> None:
        """
        Computes movie popularity metrics, Bayesian weighted ratings,
        and user activity profiles.
        """
        # Movie stats
        movie_stats = self.ratings_df.groupby("movieId")["rating"].agg(
            rating_count="count", rating_mean="mean", rating_std="std"
        ).reset_index()
        movie_stats["rating_std"] = movie_stats["rating_std"].fillna(0.0)

        # Bayesian Weighted Rating: WR = (v / (v+m)) * R + (m / (v+m)) * C
        # where v = rating_count, m = threshold (10 ratings), R = rating_mean, C = global_mean
        m_threshold = 10
        C = self.global_mean_rating
        movie_stats["weighted_rating"] = movie_stats.apply(
            lambda row: (
                (row["rating_count"] / (row["rating_count"] + m_threshold)) * row["rating_mean"]
                + (m_threshold / (row["rating_count"] + m_threshold)) * C
            ),
            axis=1,
        )

        self.movies_df = self.movies_df.merge(movie_stats, on="movieId", how="left")
        self.movies_df["rating_count"] = self.movies_df["rating_count"].fillna(0).astype(int)
        self.movies_df["rating_mean"] = self.movies_df["rating_mean"].fillna(C)
        self.movies_df["rating_std"] = self.movies_df["rating_std"].fillna(0.0)
        self.movies_df["weighted_rating"] = self.movies_df["weighted_rating"].fillna(C)

        # User stats
        user_stats = self.ratings_df.groupby("userId")["rating"].agg(
            user_rating_count="count", user_rating_mean="mean"
        ).reset_index()
        self.ratings_df = self.ratings_df.merge(user_stats, on="userId", how="left")

        # Extract unique genres
        all_genres = set()
        for g_str in self.movies_df["genres"]:
            for g in str(g_str).split("|"):
                if g.strip() and g.strip() != "Unknown":
                    all_genres.add(g.strip())
        self.unique_genres = sorted(list(all_genres))

    def create_user_item_matrix(self) -> pd.DataFrame:
        """Creates the user-item rating pivot matrix with unrated items as NaN."""
        user_item_matrix = self.ratings_df.pivot(
            index="userId", columns="movieId", values="rating"
        )
        return user_item_matrix

    def split_train_test(
        self, test_ratio: float = 0.20, random_state: int = 42
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Splits ratings into training and test sets per user to prevent data leakage.
        Ensures each user in test set has training history.
        """
        np.random.seed(random_state)
        test_indices = []

        for user_id, group in self.ratings_df.groupby("userId"):
            n_ratings = len(group)
            if n_ratings >= 5:
                n_test = max(1, int(n_ratings * test_ratio))
                chosen = np.random.choice(group.index, size=n_test, replace=False)
                test_indices.extend(chosen)

        test_idx_set = set(test_indices)
        train_df = self.ratings_df.loc[~self.ratings_df.index.isin(test_idx_set)].copy()
        test_df = self.ratings_df.loc[self.ratings_df.index.isin(test_idx_set)].copy()

        return train_df, test_df

    def run_pipeline(self) -> Dict[str, Any]:
        """Executes full preprocessing pipeline and returns processed structures."""
        self.load_raw_data()
        self.clean_datasets()
        self.compute_movie_and_user_features()
        train_ratings, test_ratings = self.split_train_test()
        user_item_matrix = self.create_user_item_matrix()

        return {
            "movies": self.movies_df,
            "ratings": self.ratings_df,
            "links": self.links_df,
            "reviews": self.reviews_df,
            "train_ratings": train_ratings,
            "test_ratings": test_ratings,
            "user_item_matrix": user_item_matrix,
            "unique_genres": self.unique_genres,
            "global_mean_rating": self.global_mean_rating,
        }


if __name__ == "__main__":
    print("Testing DataPreprocessor module...")
    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()
    print("Preprocessing completed successfully!")
    print(f"Movies count: {len(data['movies'])}")
    print(f"Ratings count: {len(data['ratings'])}")
    print(f"Reviews count: {len(data['reviews'])}")
    print(f"Train ratings: {len(data['train_ratings'])}, Test ratings: {len(data['test_ratings'])}")
    print(f"User-Item matrix shape: {data['user_item_matrix'].shape}")
    print(f"Global mean rating: {data['global_mean_rating']:.2f}")
    print(f"Sample genres: {data['unique_genres'][:8]}")
