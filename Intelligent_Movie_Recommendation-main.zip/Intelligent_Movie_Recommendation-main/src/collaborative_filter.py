"""
Intelligent Movie Recommendation System
Module 4: Collaborative Filtering Engine via SVD
------------------------------------------------
Implements matrix factorization using Singular Value Decomposition (TruncatedSVD),
user bias normalization, latent user/item representations, similar user analysis,
and predicted ratings for unseen movies without data leakage.
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Tuple
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity


class CollaborativeFilteringSVD:
    """
    De-biased SVD Matrix Factorization collaborative filter.
    Trained strictly on training partition to prevent data leakage.
    """

    def __init__(self, n_components: int = 20, random_state: int = 42, models_dir: str = None):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        self.n_components = n_components
        self.random_state = random_state
        self.svd = TruncatedSVD(n_components=n_components, random_state=random_state)

        self.user_item_matrix = None
        self.user_means = None
        self.item_means = None
        self.global_mean = 3.5

        self.user_latent = None
        self.item_latent = None
        self.user_id_to_idx = {}
        self.idx_to_user_id = {}
        self.movie_id_to_idx = {}
        self.idx_to_movie_id = {}
        self.movies_df = None
        self.is_fitted = False

    def fit(self, train_ratings_df: pd.DataFrame, movies_df: pd.DataFrame):
        """
        Fits de-biased SVD model on training ratings data.
        Ensures zero data leakage.
        """
        self.movies_df = movies_df.copy()
        self.global_mean = float(train_ratings_df["rating"].mean())

        # Build pivot table
        pivot = train_ratings_df.pivot(index="userId", columns="movieId", values="rating")
        self.user_id_to_idx = {uid: i for i, uid in enumerate(pivot.index)}
        self.idx_to_user_id = {i: uid for uid, i in self.user_id_to_idx.items()}

        self.movie_id_to_idx = {mid: j for j, mid in enumerate(pivot.columns)}
        self.idx_to_movie_id = {j: mid for mid, j in self.movie_id_to_idx.items()}

        # Compute user means for de-biasing
        self.user_means = pivot.mean(axis=1)
        self.item_means = pivot.mean(axis=0)

        # De-bias ratings: subtract user mean, fill missing with 0 (neutral prior)
        normalized_pivot = pivot.sub(self.user_means, axis=0).fillna(0.0)

        # Perform Truncated SVD
        # user_latent is shape (n_users, n_components)
        self.user_latent = self.svd.fit_transform(normalized_pivot.values)
        # item_latent is shape (n_items, n_components)
        self.item_latent = self.svd.components_.T

        self.user_item_matrix = pivot
        self.is_fitted = True

        explained_var = float(np.sum(self.svd.explained_variance_ratio_)) * 100
        print(f"SVD model fitted with {self.n_components} components.")
        print(f"Explained variance ratio: {explained_var:.2f}%")

    def predict_rating(self, user_id: int, movie_id: int) -> float:
        """
        Predicts rating for a specific user and movie on a 0.5 - 5.0 scale.
        Includes bias compensation and cold-start fallback.
        """
        if not self.is_fitted:
            raise RuntimeError("Model must be fitted before predicting.")

        user_exists = user_id in self.user_id_to_idx
        movie_exists = movie_id in self.movie_id_to_idx

        # Case 1: Both user and movie known
        if user_exists and movie_exists:
            u_idx = self.user_id_to_idx[user_id]
            m_idx = self.movie_id_to_idx[movie_id]

            user_vec = self.user_latent[u_idx]
            item_vec = self.item_latent[m_idx]

            latent_interaction = float(np.dot(user_vec, item_vec))
            u_mean = float(self.user_means.get(user_id, self.global_mean))
            predicted = u_mean + latent_interaction

        # Case 2: New user, known movie
        elif not user_exists and movie_exists:
            predicted = float(self.item_means.get(movie_id, self.global_mean))

        # Case 3: Known user, new movie
        elif user_exists and not movie_exists:
            predicted = float(self.user_means.get(user_id, self.global_mean))

        # Case 4: Completely cold start
        else:
            predicted = self.global_mean

        # Bound to realistic rating scale [0.5, 5.0]
        return float(np.clip(predicted, 0.5, 5.0))

    def get_similar_users(self, user_id: int, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Analyzes user preferences in latent space to discover similar users.
        """
        if not self.is_fitted or user_id not in self.user_id_to_idx:
            return []

        u_idx = self.user_id_to_idx[user_id]
        target_vec = self.user_latent[u_idx].reshape(1, -1)

        sim_matrix = cosine_similarity(target_vec, self.user_latent).flatten()
        sorted_indices = sim_matrix.argsort()[::-1]

        similar_users = []
        for idx in sorted_indices:
            if idx == u_idx:
                continue
            sim_uid = self.idx_to_user_id[idx]
            similar_users.append({
                "userId": sim_uid,
                "similarity": round(float(sim_matrix[idx]), 4),
                "user_mean_rating": round(float(self.user_means.get(sim_uid, self.global_mean)), 2)
            })
            if len(similar_users) >= top_k:
                break

        return similar_users

    def recommend_for_user(
        self,
        user_id: int,
        top_n: int = 10,
        exclude_seen: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Generates Top-N movie recommendations with predicted ratings for a user using vectorized dot product.
        """
        if not self.is_fitted:
            raise RuntimeError("Model must be fitted before recommending.")

        user_exists = user_id in self.user_id_to_idx
        seen_movies = set()

        if user_exists and exclude_seen and self.user_item_matrix is not None:
            try:
                user_ratings = self.user_item_matrix.loc[user_id]
                seen_movies = set(user_ratings.dropna().index)
            except Exception:
                seen_movies = set()

        if user_exists:
            u_idx = self.user_id_to_idx[user_id]
            user_vec = self.user_latent[u_idx]
            u_mean = float(self.user_means.get(user_id, self.global_mean))
            latent_scores = np.dot(self.item_latent, user_vec)
            predicted_ratings = np.clip(u_mean + latent_scores, 0.5, 5.0)

            ranked_indices = np.argsort(predicted_ratings)[::-1]
            recs = []
            for m_idx in ranked_indices:
                mid = self.idx_to_movie_id[m_idx]
                if mid in seen_movies:
                    continue
                recs.append((mid, float(predicted_ratings[m_idx])))
                if len(recs) >= top_n:
                    break
        else:
            recs = []
            cands = self.movies_df[~self.movies_df["movieId"].isin(seen_movies)].sort_values(
                by="weighted_rating", ascending=False
            ).head(top_n)
            for _, r in cands.iterrows():
                recs.append((int(r["movieId"]), float(r.get("weighted_rating", self.global_mean))))

        # Metadata dictionary lookup
        movie_dict = getattr(self, "_movie_meta_dict", None)
        if movie_dict is None:
            movie_dict = self.movies_df.set_index("movieId").to_dict(orient="index")
            self._movie_meta_dict = movie_dict

        results = []
        for mid, pred_r in recs:
            meta = movie_dict.get(mid, {})
            results.append({
                "movieId": mid,
                "title": meta.get("title", f"Movie {mid}"),
                "genres": meta.get("genres", "Unknown"),
                "predicted_rating": round(pred_r, 2),
                "rating_count": int(meta.get("rating_count", 0)),
            })

        return results

    def save_model(self, filename: str = "collaborative_svd.joblib") -> str:
        """Persists trained SVD artifacts using Joblib."""
        save_path = os.path.join(self.models_dir, filename)
        payload = {
            "svd": self.svd,
            "n_components": self.n_components,
            "user_latent": self.user_latent,
            "item_latent": self.item_latent,
            "user_means": self.user_means,
            "item_means": self.item_means,
            "global_mean": self.global_mean,
            "user_id_to_idx": self.user_id_to_idx,
            "idx_to_user_id": self.idx_to_user_id,
            "movie_id_to_idx": self.movie_id_to_idx,
            "idx_to_movie_id": self.idx_to_movie_id,
            "movies_df": self.movies_df,
            "user_item_matrix": self.user_item_matrix,
            "is_fitted": self.is_fitted,
        }
        joblib.dump(payload, save_path)
        print(f"Collaborative filtering model saved successfully to {save_path}")
        return save_path

    def load_model(self, filename: str = "collaborative_svd.joblib") -> bool:
        """Loads persisted SVD model components."""
        load_path = os.path.join(self.models_dir, filename)
        if not os.path.exists(load_path):
            return False
        payload = joblib.load(load_path)
        self.svd = payload["svd"]
        self.n_components = payload["n_components"]
        self.user_latent = payload["user_latent"]
        self.item_latent = payload["item_latent"]
        self.user_means = payload["user_means"]
        self.item_means = payload["item_means"]
        self.global_mean = payload["global_mean"]
        self.user_id_to_idx = payload["user_id_to_idx"]
        self.idx_to_user_id = payload["idx_to_user_id"]
        self.movie_id_to_idx = payload["movie_id_to_idx"]
        self.idx_to_movie_id = payload["idx_to_movie_id"]
        self.movies_df = payload["movies_df"]
        self.user_item_matrix = payload.get("user_item_matrix", None)
        self.is_fitted = payload["is_fitted"]
        print(f"Collaborative filtering model loaded from {load_path}")
        return True


if __name__ == "__main__":
    print("Testing CollaborativeFilteringSVD module...")
    from preprocessing import DataPreprocessor

    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    cf_model = CollaborativeFilteringSVD(n_components=20)
    cf_model.fit(data["train_ratings"], data["movies"])

    # Test prediction
    test_user = 1
    test_movie = 50  # The Usual Suspects (1995)
    pred = cf_model.predict_rating(test_user, test_movie)
    print(f"\nPredicted rating for User {test_user} on Movie {test_movie}: {pred:.2f}★")

    # Test similar users
    sim_users = cf_model.get_similar_users(test_user, top_k=3)
    print(f"\nSimilar users to User {test_user}:")
    for u in sim_users:
        print(f"User {u['userId']} | Cosine Similarity: {u['similarity']:.4f}")

    # Test top 5 recommendations
    recs = cf_model.recommend_for_user(test_user, top_n=5)
    print(f"\nTop 5 Collaborative Recommendations for User {test_user}:")
    for i, r in enumerate(recs, 1):
        print(f"{i}. {r['title']} | Predicted: {r['predicted_rating']}★ | Genres: {r['genres']}")

    # Save model
    cf_model.save_model()
