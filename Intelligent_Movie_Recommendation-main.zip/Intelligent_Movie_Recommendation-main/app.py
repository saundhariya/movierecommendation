"""
Intelligent Movie Recommendation System Using Reviews and User Behaviour
========================================================================
Advanced Streamlit Web Application
----------------------------------
Features:
- Dark Cinematic UI (Navy, Black, Purple, Blue accents)
- Multi-page navigation (Home, Personalized Recs, Movie Explorer, Sentiment, Rating Prediction, Analytics)
- Machine Learning & NLP integration (TF-IDF, Cosine Similarity, SVD, VADER, Hybrid Recommender)
- Real-time interactive model weight tuning and review analyzer
- Academic evaluation benchmarks and rich data visualizations
"""

import os
import sys
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

# Add src to system path for clean imports
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(BASE_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from preprocessing import DataPreprocessor
from sentiment_analysis import SentimentAnalysisEngine
from content_recommender import ContentBasedRecommender
from collaborative_filter import CollaborativeFilteringSVD
from hybrid_recommender import HybridRecommenderEngine
from rating_prediction import RatingPredictionService
from evaluation import RecommendationEvaluator
import visualization as viz

# -----------------------------------------------------------------------------
# Streamlit App Configuration
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="CineAI | Intelligent Movie Recommender",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -----------------------------------------------------------------------------
# Custom Cinematic Styling (CSS)
# -----------------------------------------------------------------------------
st.markdown("""
<style>
    /* Dark Cinematic Theme */
    .stApp {
        background-color: #0A0E17;
        color: #F8FAFC;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Top Header Bar */
    header[data-testid="stHeader"] {
        background: rgba(10, 14, 23, 0.85);
        backdrop-filter: blur(12px);
    }
    
    /* Sidebar Styling */
    section[data-testid="stSidebar"] {
        background-color: #0F172A;
        border-right: 1px solid #1E293B;
    }
    
    /* Custom Card Style */
    .cine-card {
        background: linear-gradient(135deg, #131D31 0%, #1A243B 100%);
        border: 1px solid #1E293B;
        border-radius: 12px;
        padding: 18px;
        margin-bottom: 16px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .cine-card:hover {
        transform: translateY(-2px);
        border-color: #8B5CF6;
        box-shadow: 0 10px 25px -5px rgba(139, 92, 246, 0.2);
    }
    
    /* Hero Banner */
    .hero-banner {
        background: linear-gradient(135deg, #1E1B4B 0%, #31104B 50%, #0F172A 100%);
        border: 1px solid #4338CA;
        border-radius: 16px;
        padding: 32px;
        margin-bottom: 24px;
        box-shadow: 0 20px 40px -15px rgba(99, 102, 241, 0.25);
    }
    
    /* Badges */
    .genre-badge {
        display: inline-block;
        background-color: rgba(56, 189, 248, 0.12);
        color: #38BDF8;
        border: 1px solid rgba(56, 189, 248, 0.3);
        border-radius: 6px;
        padding: 2px 8px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 4px;
        margin-bottom: 4px;
    }
    .rating-badge {
        display: inline-block;
        background-color: rgba(245, 158, 11, 0.15);
        color: #F59E0B;
        border: 1px solid rgba(245, 158, 11, 0.4);
        border-radius: 6px;
        padding: 2px 8px;
        font-size: 0.85rem;
        font-weight: 700;
    }
    .score-badge {
        display: inline-block;
        background-color: rgba(139, 92, 246, 0.15);
        color: #A78BFA;
        border: 1px solid rgba(139, 92, 246, 0.4);
        border-radius: 6px;
        padding: 2px 8px;
        font-size: 0.85rem;
        font-weight: 700;
    }
    
    /* Sentiment Badges */
    .sent-pos {
        background-color: rgba(16, 185, 129, 0.15);
        color: #10B981;
        border: 1px solid rgba(16, 185, 129, 0.4);
        border-radius: 6px;
        padding: 3px 8px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    .sent-neu {
        background-color: rgba(56, 189, 248, 0.15);
        color: #38BDF8;
        border: 1px solid rgba(56, 189, 248, 0.4);
        border-radius: 6px;
        padding: 3px 8px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    .sent-neg {
        background-color: rgba(239, 68, 68, 0.15);
        color: #EF4444;
        border: 1px solid rgba(239, 68, 68, 0.4);
        border-radius: 6px;
        padding: 3px 8px;
        font-size: 0.8rem;
        font-weight: 600;
    }

    /* Explanation Quote */
    .rec-reason {
        background: rgba(15, 23, 42, 0.6);
        border-left: 3px solid #8B5CF6;
        padding: 8px 12px;
        border-radius: 0 6px 6px 0;
        font-size: 0.85rem;
        color: #CBD5E1;
        margin-top: 8px;
    }
</style>
""", unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# Resource Caching & Model Initializer
# -----------------------------------------------------------------------------
@st.cache_resource(show_spinner="Loading datasets and AI models...")
def initialize_system():
    """Loads datasets, initializes pipelines, and loads trained model checkpoints."""
    preprocessor = DataPreprocessor()
    data = preprocessor.run_pipeline()

    # Load Collaborative Filtering
    cf_model = CollaborativeFilteringSVD()
    if not cf_model.load_model():
        cf_model.fit(data["train_ratings"], data["movies"])
        cf_model.save_model()

    # Load Content-Based Recommender
    cb_model = ContentBasedRecommender()
    if not cb_model.load_model():
        cb_model.fit(data["movies"], data["reviews"])
        cb_model.save_model()

    # Load Sentiment Engine
    sentiment_engine = SentimentAnalysisEngine()
    sentiment_engine.load_model()
    processed_reviews = sentiment_engine.process_reviews_dataframe(data["reviews"])
    movie_sentiments_df = sentiment_engine.compute_movie_sentiment_aggregates(processed_reviews)

    # Load Hybrid Engine
    hybrid_engine = HybridRecommenderEngine(
        cf_model=cf_model, cb_model=cb_model, sentiment_engine=sentiment_engine
    )
    if not hybrid_engine.load_model():
        hybrid_engine.fit(data["movies"], data["ratings"], data["reviews"], data["train_ratings"])
        hybrid_engine.save_model()

    # Load Rating Prediction Service
    rating_service = RatingPredictionService()
    rating_service.initialize(data["movies"], data["ratings"], hybrid_engine.sentiment_map)

    # Load Evaluation Results
    evaluator = RecommendationEvaluator()
    eval_df = evaluator.load_results()

    return {
        "preprocessor": preprocessor,
        "data": data,
        "cf_model": cf_model,
        "cb_model": cb_model,
        "sentiment_engine": sentiment_engine,
        "processed_reviews": processed_reviews,
        "movie_sentiments_df": movie_sentiments_df,
        "hybrid_engine": hybrid_engine,
        "rating_service": rating_service,
        "eval_df": eval_df,
    }


# Initialize components
system = initialize_system()
movies_df = system["data"]["movies"]
ratings_df = system["data"]["ratings"]
reviews_df = system["processed_reviews"]
unique_genres = system["data"]["unique_genres"]
hybrid_engine = system["hybrid_engine"]
rating_service = system["rating_service"]
cb_model = system["cb_model"]
sentiment_engine = system["sentiment_engine"]
eval_df = system["eval_df"]


# -----------------------------------------------------------------------------
# Sidebar Navigation
# -----------------------------------------------------------------------------
with st.sidebar:
    st.markdown("## 🎬 **CineAI Recommender**")
    st.markdown("<p style='color: #94A3B8; font-size: 0.85rem;'>Intelligent Movie Recommendation System Using Reviews & User Behaviour</p>", unsafe_allow_html=True)
    st.markdown("---")

    page = st.radio(
        "Navigation",
        [
            "🏠 Home Dashboard",
            "🎯 Personalized Recommendations",
            "🔍 Movie Explorer",
            "💬 Sentiment Analysis",
            "🔮 Rating Prediction",
            "📊 Analytics Dashboard",
        ],
        index=0
    )

    st.markdown("---")
    st.markdown("### ⚙️ System Status")
    st.markdown(f"**Movies Indexed:** `{len(movies_df):,}`")
    st.markdown(f"**Ratings Analyzed:** `{len(ratings_df):,}`")
    st.markdown(f"**Reviews Processed:** `{len(reviews_df):,}`")
    st.markdown(f"**Active Users:** `{ratings_df['userId'].nunique():,}`")

    st.markdown("---")
    st.caption("Developed by Senior AI/ML Developer | Academic Project")


# =============================================================================
# PAGE 1: HOME DASHBOARD
# =============================================================================
if page == "🏠 Home Dashboard":
    st.markdown("""
    <div class="hero-banner">
        <h1 style="color: #FFFFFF; font-size: 2.2rem; font-weight: 800; margin-bottom: 8px;">
            Intelligent Movie Recommendation System
        </h1>
        <p style="color: #C7D2FE; font-size: 1.05rem; margin-bottom: 16px;">
            Powered by Collaborative Matrix Factorization (SVD), Content-Based TF-IDF Cosine Similarity,
            and VADER Natural Language Sentiment Analysis.
        </p>
    </div>
    """, unsafe_allow_html=True)

    # Key Metrics Bar
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Catalog Movies", f"{len(movies_df):,}")
    with col2:
        st.metric("User Ratings", f"{len(ratings_df):,}")
    with col3:
        st.metric("Audience Reviews", f"{len(reviews_df):,}")
    with col4:
        st.metric("Mean System Rating", f"{ratings_df['rating'].mean():.2f} ★")

    st.markdown("### 🔎 Quick Search Catalog")
    search_query = st.text_input("Enter movie title or keyword:", placeholder="e.g. Inception, Toy Story, Pulp Fiction...")
    if search_query.strip():
        matches = movies_df[movies_df["clean_title"].str.contains(search_query.strip(), case=False, na=False)].head(6)
        if not matches.empty:
            st.markdown(f"**Found {len(matches)} matching titles:**")
            search_cols = st.columns(min(3, len(matches)))
            for idx, (_, row) in enumerate(matches.iterrows()):
                col = search_cols[idx % len(search_cols)]
                with col:
                    st.markdown(f"""
                    <div class="cine-card">
                        <div style="font-size: 1.05rem; font-weight: 700; color: #FFFFFF; margin-bottom: 4px;">{row['title']}</div>
                        <div>{' '.join([f'<span class=\"genre-badge\">{g}</span>' for g in str(row['genres']).split('|')[:3]])}</div>
                        <div style="margin-top: 8px;">
                            <span class="rating-badge">★ {row.get('rating_mean', 3.5):.2f}</span>
                            <span style="color: #94A3B8; font-size: 0.8rem; margin-left: 8px;">({int(row.get('rating_count', 0))} reviews)</span>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
        else:
            st.info("No matching movies found. Try another search term.")

    st.markdown("---")
    st.markdown("### 🔥 Trending & Highest Rated Titles (Bayesian Weighted)")
    trending = movies_df.sort_values(by="weighted_rating", ascending=False).head(8)
    t_cols = st.columns(4)
    for idx, (_, row) in enumerate(trending.iterrows()):
        col = t_cols[idx % 4]
        with col:
            genres_html = " ".join([f"<span class='genre-badge'>{g}</span>" for g in str(row['genres']).split("|")[:2]])
            st.markdown(f"""
            <div class="cine-card">
                <div style="font-size: 1rem; font-weight: 700; color: #FFFFFF; height: 48px; overflow: hidden;">{row['title']}</div>
                <div style="margin-top: 6px;">{genres_html}</div>
                <div style="margin-top: 10px; display: flex; justify-content: space-between; align-items: center;">
                    <span class="rating-badge">★ {row['weighted_rating']:.2f}</span>
                    <span style="color: #64748B; font-size: 0.75rem;">{int(row['rating_count']):,} votes</span>
                </div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 🎭 Browse By Favorite Genre")
    selected_genre = st.selectbox("Select a genre to explore top-rated gems:", unique_genres, index=0)
    genre_movies = movies_df[movies_df["genres"].str.contains(selected_genre, case=False, na=False)]
    top_genre_movies = genre_movies.sort_values(by="weighted_rating", ascending=False).head(4)

    g_cols = st.columns(4)
    for idx, (_, row) in enumerate(top_genre_movies.iterrows()):
        col = g_cols[idx]
        with col:
            st.markdown(f"""
            <div class="cine-card">
                <div style="font-size: 0.95rem; font-weight: 700; color: #FFFFFF; height: 42px; overflow: hidden;">{row['title']}</div>
                <div style="margin-top: 6px;"><span class="genre-badge">{selected_genre}</span></div>
                <div style="margin-top: 8px;">
                    <span class="rating-badge">★ {row['weighted_rating']:.2f}</span>
                    <span style="color: #64748B; font-size: 0.75rem; margin-left: 6px;">{int(row['rating_count'])} ratings</span>
                </div>
            </div>
            """, unsafe_allow_html=True)


# =============================================================================
# PAGE 2: PERSONALIZED RECOMMENDATIONS
# =============================================================================
elif page == "🎯 Personalized Recommendations":
    st.markdown("## 🎯 Personalized Hybrid Recommendations")
    st.markdown("Analyze user viewing history, compute collaborative latent preferences, and generate Top 10 recommendations with transparent reasoning.")

    # User Selection Row
    col_u1, col_u2 = st.columns([1, 2])
    with col_u1:
        user_id_input = st.number_input(
            "Enter User ID (1 to 610):",
            min_value=1,
            max_value=int(ratings_df["userId"].max()),
            value=1,
            step=1
        )
    with col_u2:
        st.markdown("<div style='margin-top: 28px;'><span style='color: #94A3B8;'>Tip: Users with distinct taste profiles: <b>User 1</b> (Adventure/Sci-Fi), <b>User 10</b> (Comedy/Drama), <b>User 50</b> (Classic Cinema).</span></div>", unsafe_allow_html=True)

    # Dynamic Weighting Expanders
    with st.expander("🛠️ Customize Hybrid Weighting Engine", expanded=False):
        st.write("Adjust the importance of each algorithmic component (weights auto-normalize to sum to 100%):")
        w_col1, w_col2, w_col3, w_col4 = st.columns(4)
        with w_col1:
            w_cf = st.slider("Collaborative SVD", 0.0, 1.0, 0.40, 0.05)
        with w_col2:
            w_cb = st.slider("Content Profile", 0.0, 1.0, 0.30, 0.05)
        with w_col3:
            w_pop = st.slider("Popularity Quality", 0.0, 1.0, 0.15, 0.05)
        with w_col4:
            w_sent = st.slider("Review Sentiment", 0.0, 1.0, 0.15, 0.05)

        hybrid_engine.set_weights(w_cf, w_cb, w_pop, w_sent)

    st.markdown("---")

    # Analyze User History
    user_history = ratings_df[ratings_df["userId"] == user_id_input].merge(movies_df, on="movieId")
    if not user_history.empty:
        col_h1, col_h2 = st.columns([2, 1])
        with col_h1:
            st.markdown(f"### 📜 Viewing Profile: User {user_id_input}")
            st.markdown(f"**Total Movies Rated:** `{len(user_history)}` | **Mean Rating:** `{user_history['rating'].mean():.2f} ★`")

            # Show Top 4 Rated Movies by this user
            top_rated = user_history.sort_values(by="rating", ascending=False).head(4)
            hist_cols = st.columns(4)
            for idx, (_, row) in enumerate(top_rated.iterrows()):
                with hist_cols[idx]:
                    st.markdown(f"""
                    <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid #1E293B; border-radius: 8px; padding: 10px; font-size: 0.8rem;">
                        <div style="font-weight: 700; color: #FFFFFF; height: 36px; overflow: hidden;">{row['title']}</div>
                        <div style="color: #F59E0B; margin-top: 4px;">Rated: {row['rating']} ★</div>
                    </div>
                    """, unsafe_allow_html=True)

        with col_h2:
            # Genre preference breakdown
            all_user_genres = []
            for g_str in user_history[user_history["rating"] >= 3.5]["genres"]:
                for g in str(g_str).split("|"):
                    if g.strip() and g.strip() != "Unknown":
                        all_user_genres.append(g.strip())
            if all_user_genres:
                top_genres_series = pd.Series(all_user_genres).value_counts().head(4)
                st.markdown("**Top Preferred Genres:**")
                st.markdown(" ".join([f"<span class='genre-badge'>{g} ({c})</span>" for g, c in top_genres_series.items()]), unsafe_allow_html=True)

    st.markdown("---")
    st.markdown(f"### 🏆 Top 10 Personalized Recommendations for User {user_id_input}")

    # Generate hybrid recommendations
    with st.spinner("Generating personalized hybrid recommendations..."):
        recs = hybrid_engine.recommend_hybrid(user_id=user_id_input, top_n=10)

    if recs:
        for idx, rec in enumerate(recs, 1):
            genres_html = " ".join([f"<span class='genre-badge'>{g}</span>" for g in str(rec['genres']).split("|")[:3]])
            col_r1, col_r2 = st.columns([3, 1])

            with col_r1:
                st.markdown(f"""
                <div class="cine-card">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="font-size: 1.15rem; font-weight: 800; color: #FFFFFF;">#{idx} {rec['title']}</span>
                            <div style="margin-top: 4px;">{genres_html}</div>
                        </div>
                        <div style="text-align: right;">
                            <span class="rating-badge">Predicted: {rec['predicted_rating']} ★</span>
                            <div style="margin-top: 4px;"><span class="score-badge">Match: {rec['hybrid_score']*100:.1f}%</span></div>
                        </div>
                    </div>
                    <div class="rec-reason">💡 {rec['explanation']}</div>
                    <div style="display: flex; gap: 16px; margin-top: 10px; font-size: 0.75rem; color: #94A3B8;">
                        <span>CF Score: <b>{rec['cf_score']:.2f}</b></span>
                        <span>Content Similarity: <b>{rec['content_score']:.2f}</b></span>
                        <span>Popularity: <b>{rec['popularity_score']:.2f}</b></span>
                        <span>Sentiment: <b>{rec['sentiment_score']:.2f}</b></span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            with col_r2:
                # Direct prediction button
                if st.button(f"Analyze #{rec['movieId']}", key=f"btn_rec_{rec['movieId']}"):
                    st.session_state["predict_user"] = user_id_input
                    st.session_state["predict_movie"] = rec["movieId"]
                    st.info(f"Loaded Movie #{rec['movieId']} into Rating Prediction page.")
    else:
        st.warning("No recommendations available for this user.")


# =============================================================================
# PAGE 3: MOVIE EXPLORER
# =============================================================================
elif page == "🔍 Movie Explorer":
    st.markdown("## 🔍 Movie Catalog Explorer")
    st.markdown("Search any movie in the dataset, inspect detailed metadata, and find the Top 5 or Top 10 most similar movies.")

    # Search and Filter Controls
    col_f1, col_f2 = st.columns([2, 1])
    with col_f1:
        movie_titles_list = sorted(movies_df["clean_title"].dropna().unique().tolist())
        selected_title = st.selectbox(
            "Select or type movie title:",
            movie_titles_list,
            index=movie_titles_list.index("Toy Story") if "Toy Story" in movie_titles_list else 0
        )
    with col_f2:
        genre_filter = st.selectbox("Filter similar movies by genre (optional):", ["All Genres"] + unique_genres)
        filter_genre_param = None if genre_filter == "All Genres" else genre_filter

    # Locate movie
    target_row = movies_df[movies_df["clean_title"] == selected_title].iloc[0]
    target_mid = int(target_row["movieId"])

    # Metadata Display Card
    st.markdown(f"""
    <div class="cine-card" style="border-left: 4px solid #8B5CF6;">
        <h2 style="color: #FFFFFF; margin-bottom: 6px;">{target_row['title']}</h2>
        <div>{' '.join([f'<span class=\"genre-badge\">{g}</span>' for g in str(target_row['genres']).split('|')])}</div>
        <div style="margin-top: 12px; display: flex; gap: 24px; font-size: 0.9rem; color: #CBD5E1;">
            <span>Release Year: <b>{target_row.get('year', 'N/A')}</b></span>
            <span>Average Rating: <b style="color: #F59E0B;">{target_row.get('rating_mean', 3.5):.2f} ★</b></span>
            <span>Total Ratings: <b>{int(target_row.get('rating_count', 0)):,}</b></span>
            <span>IMDb ID: <b>{target_row.get('imdbId', 'N/A')}</b></span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Similar Movies Section
    top_k_select = st.radio("Number of similar recommendations:", [5, 10], horizontal=True)
    similar_movies = cb_model.get_similar_movies(target_mid, top_n=top_k_select, genre_filter=filter_genre_param)

    st.markdown(f"### 🎯 Top {len(similar_movies)} Similar Movies to '{selected_title}'")
    if similar_movies:
        sim_cols = st.columns(2)
        for idx, sim in enumerate(similar_movies):
            col = sim_cols[idx % 2]
            with col:
                st.markdown(f"""
                <div class="cine-card">
                    <div style="display: flex; justify-content: space-between;">
                        <span style="font-weight: 700; color: #FFFFFF; font-size: 1rem;">#{idx+1} {sim['title']}</span>
                        <span class="score-badge">Cosine Sim: {sim['similarity_score']:.3f}</span>
                    </div>
                    <div style="margin-top: 6px;">
                        {' '.join([f'<span class=\"genre-badge\">{g}</span>' for g in str(sim['genres']).split('|')[:3]])}
                    </div>
                    <div style="margin-top: 8px; font-size: 0.85rem; color: #94A3B8;">
                        Average Rating: <span style="color: #F59E0B; font-weight: bold;">{sim['rating_mean']:.2f} ★</span> 
                        ({sim['rating_count']} reviews)
                    </div>
                </div>
                """, unsafe_allow_html=True)
    else:
        st.info("No similar movies found matching the selected genre criteria.")


# =============================================================================
# PAGE 4: SENTIMENT ANALYSIS
# =============================================================================
elif page == "💬 Sentiment Analysis":
    st.markdown("## 💬 Natural Language Sentiment Analysis")
    st.markdown("Examine audience reviews, VADER polarity classification (Positive, Neutral, Negative), and test arbitrary reviews with live NLP diagnostics.")

    tab1, tab2 = st.tabs(["🎬 Movie Reviews Explorer", "🧪 Live Custom Review Tester"])

    with tab1:
        # Movie selector with reviews
        movies_with_reviews = reviews_df["movieId"].unique()
        review_movie_options = movies_df[movies_df["movieId"].isin(movies_with_reviews)]
        selected_review_title = st.selectbox(
            "Select a movie to inspect audience reviews and aggregate sentiment:",
            review_movie_options["title"].tolist()
        )

        selected_m_row = review_movie_options[review_movie_options["title"] == selected_review_title].iloc[0]
        sel_mid = int(selected_m_row["movieId"])
        movie_reviews = reviews_df[reviews_df["movieId"] == sel_mid]

        # Aggregate Sentiment Summary
        col_s1, col_s2, col_s3, col_s4 = st.columns(4)
        avg_comp = movie_reviews["sentiment_compound"].mean()
        pos_pct = (movie_reviews["sentiment_label"] == "Positive").mean() * 100
        neu_pct = (movie_reviews["sentiment_label"] == "Neutral").mean() * 100
        neg_pct = (movie_reviews["sentiment_label"] == "Negative").mean() * 100

        with col_s1:
            st.metric("Total Reviews", len(movie_reviews))
        with col_s2:
            st.metric("Avg Compound Polarity", f"{avg_comp:+.3f}")
        with col_s3:
            st.metric("Positive Reviews", f"{pos_pct:.1f}%")
        with col_s4:
            st.metric("Negative Reviews", f"{neg_pct:.1f}%")

        st.markdown("#### Individual Reviews")
        for _, r_row in movie_reviews.iterrows():
            label = r_row["sentiment_label"]
            badge_class = "sent-pos" if label == "Positive" else ("sent-neg" if label == "Negative" else "sent-neu")
            st.markdown(f"""
            <div class="cine-card">
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                    <span class="{badge_class}">{label}</span>
                    <span style="color: #94A3B8; font-size: 0.8rem;">VADER Compound: <b>{r_row['sentiment_compound']:+.3f}</b> | Date: {r_row['review_date']}</span>
                </div>
                <div style="color: #E2E8F0; font-size: 0.95rem; line-height: 1.4;">"{r_row['review_text']}"</div>
            </div>
            """, unsafe_allow_html=True)

    with tab2:
        st.markdown("### 🧪 Real-Time NLP & Sentiment Diagnostic")
        st.write("Type or paste any movie review below to perform tokenization, lemmatization, VADER scoring, and TF-IDF keyword extraction in real-time.")

        sample_text = st.text_area(
            "Enter review text:",
            value="An extraordinary triumph of modern storytelling! The visual artistry and musical score are magnificent, although the second act feels slightly long.",
            height=120
        )

        if st.button("Analyze Review", type="primary"):
            diagnosis = sentiment_engine.analyze_custom_review(sample_text)
            scores = diagnosis["scores"]

            res_c1, res_c2, res_c3, res_c4 = st.columns(4)
            with res_c1:
                label_color = "#10B981" if scores["label"] == "Positive" else ("#EF4444" if scores["label"] == "Negative" else "#38BDF8")
                st.markdown(f"**Classification:** <h3 style='color: {label_color}; margin: 0;'>{scores['label']}</h3>", unsafe_allow_html=True)
            with res_c2:
                st.metric("Compound Score", f"{scores['compound']:+.4f}")
            with res_c3:
                st.metric("Positive Probability", f"{scores['pos']:.3f}")
            with res_c4:
                st.metric("Negative Probability", f"{scores['neg']:.3f}")

            st.markdown("---")
            st.markdown(f"**Cleaned & Lemmatized Text:**")
            st.code(diagnosis["cleaned_text"], language="text")

            t_col1, t_col2 = st.columns(2)
            with t_col1:
                st.markdown(f"**Token Count:** `{diagnosis['token_count']}`")
                st.write(diagnosis["tokens"][:15])
            with t_col2:
                st.markdown("**Top Salient Keywords (TF-IDF):**")
                if diagnosis["top_keywords"]:
                    st.write(", ".join(diagnosis["top_keywords"]))
                else:
                    st.write("No vocabulary match.")


# =============================================================================
# PAGE 5: RATING PREDICTION
# =============================================================================
elif page == "🔮 Rating Prediction":
    st.markdown("## 🔮 User Rating Prediction Engine")
    st.markdown("Predict how any user will rate any movie on a 0.5 – 5.0 scale using de-biased SVD matrix factorization, baseline user/item bias terms, and sentiment adjustment.")

    col_p1, col_p2 = st.columns(2)
    with col_p1:
        default_uid = st.session_state.get("predict_user", 1)
        selected_user = st.number_input("Select User ID:", min_value=1, max_value=int(ratings_df["userId"].max()), value=int(default_uid))
    with col_p2:
        default_mid = st.session_state.get("predict_movie", 50)
        # Selectbox with titles
        all_movies_titles = movies_df[["movieId", "title"]].drop_duplicates()
        title_to_id_map = dict(zip(all_movies_titles["title"], all_movies_titles["movieId"]))
        id_to_title_map = dict(zip(all_movies_titles["movieId"], all_movies_titles["title"]))

        default_title = id_to_title_map.get(default_mid, all_movies_titles["title"].iloc[0])
        chosen_title = st.selectbox("Select Target Movie:", all_movies_titles["title"].tolist(), index=all_movies_titles["title"].tolist().index(default_title))
        target_movie_id = title_to_id_map[chosen_title]

    if st.button("Predict User Rating", type="primary"):
        res = rating_service.predict_detailed(user_id=selected_user, movie_id=target_movie_id)

        st.markdown(f"""
        <div class="cine-card" style="border: 2px solid #8B5CF6; margin-top: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: #FFFFFF; margin: 0;">{res['movie_title']}</h2>
                    <div style="color: #94A3B8; margin-top: 4px;">User ID: <b>{selected_user}</b> | Movie ID: <b>{res['movieId']}</b> | Genres: <b>{res['genres']}</b></div>
                </div>
                <div style="text-align: right;">
                    <span style="font-size: 2.2rem; font-weight: 800; color: #F59E0B;">★ {res['predicted_rating']}</span>
                    <span style="color: #94A3B8; font-size: 1rem;"> / 5.0</span>
                    <div style="color: #A78BFA; font-weight: 700; font-size: 0.9rem;">Recommendation Score: {res['recommendation_score']}%</div>
                </div>
            </div>
            
            <div class="rec-reason" style="margin-top: 16px; font-size: 0.95rem;">
                <b>Mathematical Attribution & Explanation:</b><br>{res['explanation']}
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("### 🧮 Mathematical Component Decomposition")
        comps = res["components"]
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.metric("Global Mean Rating (μ)", f"{comps['global_mean']:.3f} ★")
        with c2:
            st.metric("User Bias Term (bᵤ)", f"{comps['user_bias']:+.3f} ★", help="User's tendency to rate higher or lower than the global mean")
        with c3:
            st.metric("Item Bias Term (bᵢ)", f"{comps['item_bias']:+.3f} ★", help="Movie's tendency to be rated higher or lower than the global mean")
        with c4:
            st.metric("SVD Latent Factor (qᵢᵀ pᵤ)", f"{comps['latent_interaction']:+.3f} ★", help="Dot product interaction between user latent vector and movie latent vector")

        if res["actual_rating"] is not None:
            st.success(f"Ground Truth: User {selected_user} previously rated this movie **{res['actual_rating']} ★** (Error: {abs(res['actual_rating'] - res['predicted_rating']):.2f} ★)")


# =============================================================================
# PAGE 6: ANALYTICS DASHBOARD
# =============================================================================
elif page == "📊 Analytics Dashboard":
    st.markdown("## 📊 Comprehensive Analytics Dashboard")
    st.markdown("Data distributions, genre statistics, review sentiment patterns, and empirical recommendation benchmark comparisons.")

    tab_vis, tab_eval = st.tabs(["📈 Data Visualizations", "🏅 Model Evaluation Benchmark"])

    with tab_vis:
        st.markdown("### 1. Movie Rating Distribution Histogram")
        fig1 = viz.plot_rating_distribution(ratings_df)
        st.pyplot(fig1)

        st.markdown("---")
        st.markdown("### 2. Review Sentiment Proportions & Compound Polarity")
        fig2 = viz.plot_sentiment_distribution(reviews_df)
        st.pyplot(fig2)

        st.markdown("---")
        st.markdown("### 3. Most Popular Genres in Catalog")
        fig3 = viz.plot_genre_popularity(movies_df, top_n=12)
        st.pyplot(fig3)

    with tab_eval:
        st.markdown("### 🏅 Recommendation Algorithm Benchmark Comparison")
        st.write("Rigorous comparison of all four recommendation architectures evaluated on the held-out test split:")

        if eval_df is not None:
            st.dataframe(
                eval_df.style.highlight_min(subset=["RMSE", "MAE"], color="#312E81")
                             .highlight_max(subset=["Precision@5", "Recall@5", "Precision@10", "Recall@10"], color="#064E3B"),
                use_container_width=True
            )

            st.markdown("---")
            st.markdown("### 4. Error Metrics (RMSE & MAE) Comparison")
            fig4 = viz.plot_model_comparison(eval_df)
            st.pyplot(fig4)

            st.markdown("---")
            st.markdown("### 5. Ranking Metrics (Precision@K & Recall@K) Comparison")
            fig5 = viz.plot_ranking_metrics_comparison(eval_df)
            st.pyplot(fig5)

            st.markdown("""
            #### 📌 Key Empirical Findings & Methodology
            1. **Hybrid Synergy**: The Hybrid Engine achieves the lowest overall RMSE and MAE by balancing user-item matrix factorization with content profiles and review sentiment.
            2. **Collaborative Filtering Precision**: SVD excels at identifying personalized niche preferences, yielding the highest Precision@5 and Recall@10 for users with rich histories.
            3. **Cold-Start Resilience**: Content-based and popularity fallbacks safeguard against the cold-start deficit when user rating records are sparse.
            4. **Zero Data Leakage**: All models were trained strictly on the train partition and evaluated on an independent test partition with fixed random seeds.
            """)
        else:
            st.info("Evaluation results not found. Run `src/evaluation.py` to generate benchmark metrics.")

# Footer
st.markdown("---")
st.markdown("<div style='text-align: center; color: #64748B; font-size: 0.8rem;'>Intelligent Movie Recommendation System | Academic AI/ML Project</div>", unsafe_allow_html=True)
