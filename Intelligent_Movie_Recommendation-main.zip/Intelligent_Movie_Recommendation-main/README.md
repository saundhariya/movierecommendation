# Intelligent Movie Recommendation System Using Reviews and User Behaviour

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Streamlit App](https://img.shields.io/badge/Streamlit-1.30%2B-FF4B4B.svg)](https://streamlit.io/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-Latest-orange.svg)](https://scikit-learn.org/)
[![NLTK VADER](https://img.shields.io/badge/NLP-NLTK%20VADER-green.svg)](https://www.nltk.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

An academic, end-to-end AI-powered movie recommendation platform that fuses **Collaborative Filtering via De-biased Singular Value Decomposition (SVD)**, **Content-Based Filtering via TF-IDF & Cosine Similarity**, **Bayesian Popularity Weighting**, and **Natural Language Sentiment Analysis via NLTK VADER**.

Developed as a full-stack, research-grade machine learning system featuring a modern, cinematic dark-themed Streamlit dashboard, transparent rating predictions, explainable recommendations, and empirical benchmarking on held-out test splits.

---

## 📑 Table of Contents
1. [Project Overview](#-project-overview)
2. [Key Features](#-key-features)
3. [System Architecture](#-system-architecture)
4. [Dataset Documentation](#-dataset-documentation)
5. [Algorithmic Foundations & Mathematical Formulation](#-algorithmic-foundations--mathematical-formulation)
6. [Project Folder Structure](#-project-folder-structure)
7. [Installation & Execution Guide](#-installation--execution-guide)
8. [Sample Input & Output](#-sample-input--output)
9. [Empirical Evaluation Benchmarks](#-empirical-evaluation-benchmarks)
10. [Limitations & Future Scope](#-limitations--future-scope)

---

## 🌟 Project Overview

Traditional recommendation engines either suffer from the **Cold-Start Problem** (inability to recommend to new users or items without ratings) or miss nuanced qualitative feedback buried in **unstructured textual reviews**. 

This system addresses both limitations through an integrated hybrid recommendation paradigm:
- **Collaborative Filtering (SVD)** captures latent preference factors and hidden taste affinities.
- **Content-Based Filtering (TF-IDF)** captures semantic genre and metadata similarities.
- **Review Sentiment Analysis (VADER)** integrates qualitative audience consensus and sentiment polarity into recommendation rankings.
- **Explainable AI**: Generates human-interpretable natural language rationales for every recommendation.

---

## 🚀 Key Features

- **🏠 Home Dashboard**: Global metrics, Bayesian top-rated movies, trending titles, and real-time catalog search.
- **🎯 Personalized Recommendations**: Top 10 recommendations for any user ID, complete with predicted ratings, match percentage, and natural language explanations.
- **🔍 Movie Catalog Explorer**: Search and filter 9,700+ movies by title, year, and genre, with Top 5 / Top 10 similar movie discovery.
- **💬 Review Sentiment Analysis**: Aggregated sentiment metrics, positive/neutral/negative classification, and a **real-time custom review diagnostic playground**.
- **🔮 Transparent Rating Prediction**: Predicts user ratings on a 0.5–5.0 scale with exact mathematical component attribution ($\mu$, $b_u$, $b_i$, $q_i^T p_u$).
- **📊 Analytics Dashboard**: 5 publication-grade visualization plots and an empirical benchmark comparison table (RMSE, MAE, Precision@K, Recall@K).

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    subgraph Data Layer
        A1[MovieLens movies.csv] --> B1[Data Preprocessor]
        A2[MovieLens ratings.csv] --> B1
        A3[MovieLens links.csv] --> B1
        A4[IMDb reviews.csv] --> B1
    end

    subgraph Feature Engineering & NLP
        B1 --> C1[User-Item Rating Matrix]
        B1 --> C2[Train/Test Split 80/20]
        B1 --> C3[Metadata Text Corpus]
        B1 --> C4[NLTK VADER Sentiment Engine]
        C3 --> D1[TF-IDF Feature Extraction]
        C4 --> D2[Movie Aggregate Sentiment]
    end

    subgraph Core ML Models
        C2 --> E1[Collaborative Filter SVD]
        D1 --> E2[Content-Based Cosine Recommender]
        D2 --> E3[Hybrid Recommendation Engine]
        E1 --> E3
        E2 --> E3
        E1 --> E4[Rating Prediction Service]
    end

    subgraph Presentation Layer
        E3 --> F[Streamlit Web Application]
        E4 --> F
        D2 --> F
        G[Model Evaluation Engine] --> F
    end
```

---

## 📦 Dataset Documentation

The system utilizes official GroupLens MovieLens datasets linked with verified movie reviews via reliable identifiers:

| File | Records | Primary Columns | Purpose |
| :--- | :--- | :--- | :--- |
| `dataset/movies.csv` | 9,742 | `movieId`, `title`, `genres` | Movie catalog, release years, and genre categories. |
| `dataset/ratings.csv` | 100,836 | `userId`, `movieId`, `rating`, `timestamp` | Explicit user ratings on a 0.5 to 5.0 scale across 610 users. |
| `dataset/links.csv` | 9,742 | `movieId`, `imdbId`, `tmdbId` | Cross-dataset identifier bridge linking MovieLens to IMDb `tconst`. |
| `dataset/reviews.csv` | 1,527 | `review_id`, `movieId`, `imdbId`, `review_text`, `review_rating`, `review_date` | Textual qualitative reviews with multi-polarity sentiments. |

### Data Cleaning & Handling:
- Inconsistent and out-of-bound ratings are strictly validated and clamped to `[0.5, 5.0]`.
- Missing and duplicate rows are safely pruned.
- Release years are extracted from titles using regular expressions (e.g., `"Toy Story (1995)"` $\rightarrow$ year `1995`, title `"Toy Story"`).
- Train/Test split is stratified per user (80% train, 20% test) to prevent **data leakage**.

---

## 🧮 Algorithmic Foundations & Mathematical Formulation

### 1. Bayesian Weighted Rating (Quality Metric)
To avoid skew from movies with only 1 or 2 five-star ratings, we compute the IMDb Bayesian weighted rating:
$$WR = \left(\frac{v}{v+m}\right) R + \left(\frac{m}{v+m}\right) C$$
where:
- $v$: number of ratings for the movie
- $m$: minimum rating threshold ($m = 10$)
- $R$: average rating of the movie
- $C$: global mean rating across all movies ($C \approx 3.50$)

### 2. Content-Based TF-IDF & Cosine Similarity
Movie metadata vectors are constructed using sublinear TF-IDF term weighting:
$$\text{TF-IDF}(t, d, D) = (1 + \log(\text{TF}(t, d))) \cdot \log\left(\frac{1 + |D|}{1 + \text{DF}(t, D)}\right)$$
Pairwise similarity between movie vector $\vec{u}$ and candidate vector $\vec{v}$ is evaluated via Cosine Similarity:
$$\text{CosineSim}(\vec{u}, \vec{v}) = \frac{\vec{u} \cdot \vec{v}}{\|\vec{u}\|_2 \|\vec{v}\|_2}$$

### 3. De-biased SVD Matrix Factorization
The user-item rating matrix $R$ is de-biased by subtracting user mean ratings $\mu_u$. Missing ratings are filled with zero (representing neutral prior expectations):
$$\tilde{R}_{u, i} = R_{u, i} - \mu_u$$
Using Truncated Singular Value Decomposition with $k=20$ latent components:
$$\tilde{R} \approx U_k \Sigma_k V_k^T$$
Predicted collaborative rating:
$$\hat{R}_{u, i} = \mu_u + (U_k \Sigma_k)_u \cdot (V_k)_i^T$$

### 4. VADER NLP Sentiment Scoring
VADER computes polarity scores from lexical features, punctuation, capitalization, and syntactic negations:
$$\text{Compound} = \frac{\sum x}{\sqrt{\left(\sum x\right)^2 + \alpha}}$$
Classification rules:
- **Positive**: $\text{Compound} \ge +0.05$
- **Neutral**: $-0.05 < \text{Compound} < +0.05$
- **Negative**: $\text{Compound} \le -0.05$

### 5. Configurable Hybrid Recommendation Formulation
$$Score_{hybrid}(u, i) = w_{cf} \cdot S_{cf}(u, i) + w_{cb} \cdot S_{cb}(u, i) + w_{pop} \cdot S_{pop}(i) + w_{sent} \cdot S_{sent}(i)$$
- Weights: $w_{cf}=0.40, w_{cb}=0.30, w_{pop}=0.15, w_{sent}=0.15$ (dynamically customizable via Streamlit sliders).
- **Cold-Start Adaptation**: For unseen users, collaborative weight is automatically set to $0.0$, dynamically reallocating weight to content, popularity, and sentiment.

---

## 📁 Project Folder Structure

```text
Intelligent_Movie_Recommendation/
│
├── dataset/
│   ├── movies.csv             # MovieLens movie catalog (9,742 records)
│   ├── ratings.csv            # User ratings (100,836 ratings, 610 users)
│   ├── links.csv              # Identifiers mapping movieId to imdbId
│   └── reviews.csv            # Curated reviews dataset with sentiments
│
├── models/
│   ├── collaborative_svd.joblib     # Persisted TruncatedSVD collaborative filter
│   ├── content_recommender.joblib   # Persisted TF-IDF matrix and index lookups
│   ├── sentiment_pipeline.joblib    # Persisted VADER and TF-IDF review analyzer
│   ├── hybrid_recommender.joblib    # Persisted Hybrid weights and lookup tables
│   ├── rating_predictor.joblib      # Persisted bias terms and predictor configuration
│   ├── evaluation_results.joblib    # Cached evaluation benchmark dataframe
│   └── evaluation_results.json      # JSON export of benchmark metrics
│
├── src/
│   ├── preprocessing.py       # Module 1: Data ingestion, cleaning, split, matrices
│   ├── sentiment_analysis.py  # Module 2: Text normalization, VADER, TF-IDF
│   ├── content_recommender.py # Module 3: Content-based cosine recommender
│   ├── collaborative_filter.py# Module 4: De-biased SVD matrix factorization
│   ├── hybrid_recommender.py  # Module 5: 4-factor hybrid recommendation engine
│   ├── rating_prediction.py   # Module 6: 0.5-5.0 scale rating prediction service
│   ├── evaluation.py          # Module 7: RMSE, MAE, Precision@K, Recall@K benchmark
│   └── visualization.py       # Module 8: Publication-quality dark-themed charts
│
├── visualizations/            # Rendered benchmark and analytical PNG charts
│   ├── fig1_rating_distribution.png
│   ├── fig2_sentiment_distribution.png
│   ├── fig3_genre_popularity.png
│   ├── fig4_model_comparison.png
│   └── fig5_ranking_metrics.png
│
├── app.py                     # Full-featured Streamlit Web Application
├── requirements.txt           # Python dependencies
├── README.md                  # Comprehensive documentation
└── .gitignore                 # Version control ignore rules
```

---

## 💻 Installation & Execution Guide

### Prerequisites
- Python 3.10, 3.11, 3.12, 3.13, or 3.15
- Git

### Step 1: Clone the Repository
```bash
git clone https://github.com/<your-username>/Intelligent_Movie_Recommendation.git
cd Intelligent_Movie_Recommendation
```

### Step 2: Create and Activate a Virtual Environment
```bash
# Windows (PowerShell)
python -m venv venv
.\venv\Scripts\Activate.ps1

# Linux / macOS
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Verify or Re-Train ML Models (Optional)
The pre-trained checkpoints are stored in `models/`. To retrain any module from scratch:
```bash
# Module 1: Preprocessing & Data Extraction
python src/preprocessing.py

# Module 2: NLP & Sentiment Analysis
python src/sentiment_analysis.py

# Module 3: Content-Based Recommender
python src/content_recommender.py

# Module 4: Collaborative Filtering SVD
python src/collaborative_filter.py

# Module 5: Hybrid Recommender
python src/hybrid_recommender.py

# Module 6: Rating Prediction Service
python src/rating_prediction.py

# Module 7: Empirical Model Evaluation
python src/evaluation.py

# Module 8: Render Analytical Visualizations
python src/visualization.py
```

### Step 5: Launch the Streamlit Web Application
```bash
streamlit run app.py
```
Open your browser and navigate to `http://localhost:8501`.

---

## 📊 Sample Input & Output

### 1. Personalized Recommendations (Input: `User ID: 1`)
- **User Profile**: Active reviewer with preference for Action, Adventure, and Sci-Fi.
- **Top 5 Hybrid Output**:
  1. **Shawshank Redemption, The (1994)** — Predicted: `4.66 ★` | Match: `65.5%`
     * *Reason*: Recommended because users with similar taste rated it high (4.7★) and 85% positive audience reviews.
  2. **Lord of the Rings: The Return of the King (2003)** — Predicted: `4.51 ★` | Match: `64.3%`
     * *Reason*: Recommended because it matches your interest in Action, Adventure and users with similar taste rated it high (4.5★).
  3. **Good Will Hunting (1997)** — Predicted: `4.47 ★` | Match: `64.0%`
  4. **Life Is Beautiful (1997)** — Predicted: `4.48 ★` | Match: `63.9%`
  5. **Godfather, The (1972)** — Predicted: `4.61 ★` | Match: `63.6%`

### 2. Detailed Rating Prediction (Input: `User ID: 1`, `Movie: Usual Suspects, The (1995)`)
- **Predicted Rating**: `5.00 ★` (Ground Truth Actual Rating: `5.00 ★`, Error: `0.00 ★`)
- **Recommendation Confidence**: `100.0%`
- **Component Breakdown**:
  - Global Mean ($\mu$): `3.502 ★`
  - User Bias ($b_u$): `+0.865 ★` (frequent high-rater)
  - Item Bias ($b_i$): `+0.736 ★` (universally acclaimed title)
  - Latent Interaction ($q_i^T p_u$): `+0.218 ★`
  - Audience Sentiment: `50% positive review consensus`

---

## 🏅 Empirical Evaluation Benchmarks

All models were evaluated on an identical held-out test split (20% of ratings per user):

| Recommendation Model | RMSE (↓) | MAE (↓) | Precision@5 (↑) | Recall@5 (↑) | Precision@10 (↑) | Recall@10 (↑) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Popularity Baseline** | 1.0013 | 0.7757 | 0.1000 | 0.0313 | 0.1033 | 0.0699 |
| **Content-Based Filtering** | 0.9470 | 0.7318 | 0.0533 | 0.0142 | 0.0533 | 0.0299 |
| **Collaborative Filtering (SVD)** | 0.9599 | 0.7408 | **0.1400** | **0.0577** | **0.1033** | **0.0723** |
| **Hybrid Recommendation Engine** | **0.9283** | **0.7152** | 0.0933 | 0.0367 | 0.0800 | 0.0636 |

> **Evaluation Takeaway**:
> - The **Hybrid Engine** achieves the lowest overall prediction error (**RMSE: 0.9283, MAE: 0.7152**), outperforming individual single-paradigm methods.
> - **Collaborative Filtering (SVD)** achieves the highest ranking precision (**Precision@5: 14.0%**) for active users with established rating histories.

---

## 🔬 Limitations & Future Scope

1. **Extreme Cold-Start Sparsity**: For users with zero ratings and no specified genre preferences, collaborative filtering cannot extrapolate preferences; future iterations can integrate active-learning onboarding quizzes.
2. **Review Modality Scalability**: Transformer-based embeddings (e.g., Sentence-BERT / RoBERTa) could capture deep semantic review nuances beyond lexical VADER dictionaries.
3. **Session-Based Dynamics**: Incorporating temporal decay functions into user preferences to prioritize recent trends over historical ratings.

---

## 📜 License & Academic Integrity
This project is developed for academic evaluation purposes under the MIT License. Datasets sourced from [GroupLens Research](https://grouplens.org/datasets/movielens/) and [IMDb](https://developer.imdb.com/).
